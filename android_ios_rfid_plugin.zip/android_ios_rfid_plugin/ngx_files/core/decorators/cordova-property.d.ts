export declare function cordovaPropertyGet(pluginObj: any, key: string): any;
export declare function cordovaPropertySet(pluginObj: any, key: string, value: any): void;
