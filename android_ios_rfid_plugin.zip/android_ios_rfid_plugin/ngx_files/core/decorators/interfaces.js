export {};
//# sourceMappingURL=interfaces.js.map