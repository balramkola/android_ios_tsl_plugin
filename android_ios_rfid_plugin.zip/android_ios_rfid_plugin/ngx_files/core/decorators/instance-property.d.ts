export declare function instancePropertyGet(pluginObj: any, key: string): any;
export declare function instancePropertySet(pluginObj: any, key: string, value: any): void;
