import { Observable } from 'rxjs';
export declare function cordovaFunctionOverride(pluginObj: any, methodName: string, args?: IArguments | any[]): Observable<any>;
