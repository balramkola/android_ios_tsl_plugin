/**
 * @private
 */
export declare function get(element: Element | Window, path: string): any;
/**
 * @private
 */
export declare function getPromise(callback?: Function): Promise<any>;
