import { IonicNativePlugin } from '@ionic-native/core';
import { Observable } from 'rxjs';
export declare class BTDeviceListOriginal extends IonicNativePlugin {
    startScan(): Observable<any>;
    stopScan(): Observable<any>;
    getBondedDevices(): Observable<any>;
}

export declare const BTDeviceList: BTDeviceListOriginal;