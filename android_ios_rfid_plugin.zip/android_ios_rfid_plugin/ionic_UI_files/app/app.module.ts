import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';
import { RfidPlugin } from '@ionic-native/rfid-plugin/ngx';
import { BTDeviceList } from '@ionic-native/bt-device-list/ngx';
import { ToastController,AlertController } from '@ionic/angular';


import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [AppComponent],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule],
  providers: [
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },
    RfidPlugin,
    BTDeviceList,
    AlertController,
    ToastController
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
