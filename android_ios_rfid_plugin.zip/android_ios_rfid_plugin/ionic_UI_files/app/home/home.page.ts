import { Component , NgZone} from '@angular/core';
import { RfidPlugin } from '@ionic-native/rfid-plugin/ngx';
import { BTDeviceList } from '@ionic-native/bt-device-list/ngx';
import { ChangeDetectorRef } from '@angular/core';
import { BDevice } from '../models/bluetooth-device';
import { ToastController,AlertController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  listToggle: boolean = false;
  pairedDeviceID: number = 0;
  dataSend: string = "";
  PREFIX_LOG: string = 'IONIC UI: ';
  items = [];
  eventsTextView: string = '';
  selectedDeviceTextView: string = '';
  pairedDevices: BDevice[] = [];
  unPairedDevices: BDevice[] = [];
  devices:any[] = [];
  bDeviceInfo: BDevice;
  readerAddress: string = "1166-003793";
  libName: string = "ZEBRA";
  enable: boolean = true;
  tagList: string[] = [];
  barcodeList: string[] = [];
  connectObserver: any;
  readerEventsObserver: any;

  constructor(public rfidPlugin: RfidPlugin,private ngZone: NgZone,private changeDetector: ChangeDetectorRef,private btDeviceList: BTDeviceList) {
    
}

public viewBDeviceInfo(bDevice: BDevice): void {
  this.selectedDeviceTextView =  "Selected Device: " +bDevice.name;
  this.readerAddress = bDevice.address;
  this.changeDetector.detectChanges();
}

initZebra(){
  this.libName = "ZEBRA"
  this.startReaderEvents();
  this.initRfidReader();
}

initTsl(){
  this.libName = "TSL"
  this.startReaderEvents();
  this.initRfidReader();
}

initRfidReader() {
  this.rfidPlugin.initRfidReader(this.libName).subscribe((result) => {
    console.log(this.PREFIX_LOG + 'received lib event from plugin code: '+result);
    if (result == null) {
      return;
    }

    if (result === "NO_LIB") {//library is not available in the plugin
      this.eventsTextView = result;
    } else
      if (result === "LIB_INITIALIZED") {
        //library initialized, call connect() method
        this.eventsTextView = result;
      } else
        {
          //error occurred while initializing library
          this.eventsTextView = result;
        }

    this.changeDetector.detectChanges();
  });
}

startReaderEvents() {
  console.log(this.PREFIX_LOG + 'Subscribing to reader events');
  this.readerEventsObserver = this.rfidPlugin.readerEvents().subscribe((info) => {
    if (info == null) {
      console.log(this.PREFIX_LOG + 'received EMPTY event from plugin code');
      return;
    }
    console.log(this.PREFIX_LOG + 'received event from plugin code');
    //this.readerEventsObserver.unsubscribe;
    //calling the above unSubscribe wont stop receiving the Reader events,
    //to stop receiving reader events call below one
    //this.rfidPlugin.stopReaderEvents();

    //console.log(this.PREFIX_LOG + "event: " + info);
    console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);

    if (info.eventType === "INVENTORY_TAG") {
      this.tagList.push(info.eventValue);
    } else
      if (info.eventType === "INVENTORY_BARCODE") {
        this.barcodeList.push(info.eventValue);
      } else
        if (info.eventType === "ERROR") {
          this.eventsTextView = info.eventValue;
        } else {
          this.eventsTextView = info.eventValue;
        }

    this.changeDetector.detectChanges();
  });
}

stopReaderEvents() {
  this.rfidPlugin.stopReaderEvents();
}

connect() {
  console.log(this.PREFIX_LOG + 'connect method called');
  //use setEnableTagScan() to get Tag scan events from Plugin code
  this.setEnableTagScan(true);
  this.connectObserver = this.rfidPlugin.connect(this.readerAddress).subscribe(connectionStatus => {
    console.log(this.PREFIX_LOG + 'rfid Reader connection status:' + connectionStatus);
    this.eventsTextView = connectionStatus;
    this.changeDetector.detectChanges();
    // switch(connectionStatus){
    // UNDEFINED,
    // DISCONNECTED,
    // CONNECTING,
    // CONNECTED,
    // INTERRUPTED,
    // LOST;
    //   the above are the connection states and the remaining one is error message if something went wrong
    // }
  });

  //for unssubscribe use following
  //this.connectObserver.unsubscribe();
  //calling the above unSubscribe wont stop receiving the connection events,
  //to stop receiving the connection events, use the below
  //this.rfidPlugin.stopConnEvents();
}

disconnect() {
  console.log(this.PREFIX_LOG + 'disconnect method called');
  this.rfidPlugin.disconnect().then(result => {
    console.log(this.PREFIX_LOG + 'status:' + result);
    alert(result);
  }).catch(err => alert('Error : ' + err));
}

clear() {
  this.tagList = [];
  this.barcodeList = [];
}

setEnableTagScan(value: boolean) {
  console.log(this.PREFIX_LOG + 'setEnableTagScan method called');
  this.rfidPlugin.enableTagScan(value).then(result => {
    console.log(this.PREFIX_LOG + 'status:' + result);
  }).catch(err => alert('Error : ' + err));
}

setEnableBarcodeScan(value: boolean) {
  console.log(this.PREFIX_LOG + 'setEnableBarcodeScan method called');
  this.rfidPlugin.enableBarcodeScan(value).then(result => {
    console.log(this.PREFIX_LOG + 'status:' + result);
    //alert(result);
  }).catch(err => alert('Error : ' + err));
}

getConnectionStatus() {
  console.log(this.PREFIX_LOG + 'getConnectionStatus method called');
  this.rfidPlugin.getConnectionStatus().then(result => {
    console.log(this.PREFIX_LOG + 'status:' + result);
    // below are the connection status values which comes from plugin
    // UNDEFINED,
    // DISCONNECTED,
    // CONNECTING,
    // CONNECTED,
    // INTERRUPTED,
    // LOST
    alert(result);
  }).catch(err => alert('Error : ' + err));
}

getReaderInfo() {
  console.log(this.PREFIX_LOG + 'getReaderInfo method called');
  this.rfidPlugin.getReaderProperties().subscribe(result => {
    console.log(this.PREFIX_LOG + 'Reader info:' + result);
    console.log(this.PREFIX_LOG + 'result.eventType:' + result.eventType+'result.eventValue:'+result.eventValue);
    if (result.eventType === "READER_INFO") {
      this.tagList.push(result.eventValue);
    } else
      if (result.eventType === "ERROR") {
        this.eventsTextView = result.eventValue;
      } else {
        this.eventsTextView = result.eventValue;
      }
    this.changeDetector.detectChanges();
  });
}

scanTags() {
  console.log(this.PREFIX_LOG + 'scanTags method called');
  this.rfidPlugin.scanTags().then(result => {
    console.log(this.PREFIX_LOG + 'scanTags command status:' + result);
    // tag info results wont come here, those are available in readerEvents() subscription
    //alert(result);
  }).catch(err => alert('Error : ' + err));
}

public showBondedDevices(){
  this.pairedDevices = [];
  this.unPairedDevices = [];
  console.log(this.PREFIX_LOG + 'showBondedDevices called up in the plugin code');
  this.btDeviceList.getBondedDevices().subscribe((info) => {
    console.log(this.PREFIX_LOG + 'received event from getBondedDevices plugin code');
    if (info == null) {
      return;
    }
    
    console.log(this.PREFIX_LOG + "event: "+info);
    console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);

    if (info.eventType === "BONDED_DEVICE") {
      let jsonObj: any = JSON.parse(info.eventValue);
      let bdevice: BDevice = {
        address: jsonObj.address,
        paired: jsonObj.paired,
        name: jsonObj.name,
        rssi: 0
      };
      this.pairedDevices.push(bdevice);
      console.log(this.PREFIX_LOG + "info.eventValue.address: "+jsonObj.address);
      console.log(this.PREFIX_LOG + "info.eventValue.paired: "+jsonObj.paired);
      console.log(this.PREFIX_LOG + "info.eventValue.name: "+jsonObj.name);
    }else 
    if(info.eventType === "ERROR") {
      console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);
      this.selectedDeviceTextView = info.eventValue;
    }else
    {
      this.selectedDeviceTextView = info.eventValue;
    }
    this.changeDetector.detectChanges();
  });
}

scanDevices(){
  this.pairedDevices = [];
  this.unPairedDevices = [];
  this.showBondedDevices();
  this.btDeviceList.startScan().subscribe((info) => {
    console.log(this.PREFIX_LOG + 'received event from bt devices start scan plugin code');
    if (info == null) {
      return;
    }
    
    console.log(this.PREFIX_LOG + "event: "+info);
    console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);

      if (info.eventType === "DEVICE_FOUND") {
        let jsonObj: any = JSON.parse(info.eventValue);
        let bdevice: BDevice = {
          address: jsonObj.address,
          paired: jsonObj.paired,
          name: jsonObj.name,
          rssi: 0
        };

        if (bdevice.name == 'undefined' || !bdevice.name || bdevice.name.length === 0 || bdevice.name === "" )
        {
          console.log(this.PREFIX_LOG + "found device name is empty");
        }
        else{
          console.log(this.PREFIX_LOG + "adding found device to the list");
          this.unPairedDevices.push(bdevice);
        }
        
        console.log(this.PREFIX_LOG + "info.eventValue.address: "+jsonObj.address);
        console.log(this.PREFIX_LOG + "info.eventValue.paired: "+jsonObj.paired);
        console.log(this.PREFIX_LOG + "info.eventValue.name: "+jsonObj.name);
      } else if (info.eventType === "BONDED_DEVICE") {
        let jsonObj: any = JSON.parse(info.eventValue);
        let bdevice: BDevice = {
          address: jsonObj.address,
          paired: jsonObj.paired,
          name: jsonObj.name,
          rssi: 0
        };
        //this.pairedDevices.push(bdevice);
        console.log(this.PREFIX_LOG + "info.eventValue.address: "+jsonObj.address);
        console.log(this.PREFIX_LOG + "info.eventValue.paired: "+jsonObj.paired);
        console.log(this.PREFIX_LOG + "info.eventValue.name: "+jsonObj.name);
        //this.showBondedDevices();
      }else if (info.eventType === "DISCONNECTED") {
        let jsonObj: any = JSON.parse(info.eventValue);
        console.log(this.PREFIX_LOG + "info.eventValue.address: "+jsonObj.address);
        console.log(this.PREFIX_LOG + "info.eventValue.paired: "+jsonObj.paired);
        console.log(this.PREFIX_LOG + "info.eventValue.name: "+jsonObj.name);
        this.eventsTextView = info.eventType;
      }else if (info.eventType === "ERROR") {
        let jsonObj: any = JSON.parse(info.eventValue);
        console.log(this.PREFIX_LOG + "event type: " + info.eventType + " event info: " + info.eventValue);
        this.eventsTextView = info.eventValue;
      }else
      {
        this.eventsTextView = info.eventValue;
      }
      this.changeDetector.detectChanges();
  });

}

}