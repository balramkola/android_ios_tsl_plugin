export  class BDevice {
    name?:string= "";
    paired?:boolean= false;
    address?: string= "";
    rssi:number;
  }