package com.techm.btdevicelist;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaArgs;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;

public class BTDeviceList extends CordovaPlugin {

    private static final String TAG = "BTDeviceListPlugin";
    private static final String LOG_PREFIX = "PLUGIN: ";
    public static final int REQUEST_ENABLE_BT = 1773;
    public static final int PERMNS_REQ_CODE = 1997;

    public BluetoothAdapter mBluetoothAdapter = null;
    public static final String START_SCAN = "start_scan";
    private String mCurrentAction = "";
    private CallbackContext mBtEventsCallbackContext;
    private static final String STOP_SCAN = "stop_scan";

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        this.mBtEventsCallbackContext = null;
    }

    @Override
    public boolean execute(String action, CordovaArgs args, final CallbackContext callbackContext) {

        if (this.mBluetoothAdapter == null) {
            callbackContext.error("Device does not support Bluetooth");
            return false;
        }
        if (action.equals("start_scan")) {
            Log.d(TAG, LOG_PREFIX + "action start_scan called");
            mCurrentAction = START_SCAN;
            this.mBtEventsCallbackContext = callbackContext;
            registerAdapterStateChanges();
            initDeviceDiscovery();
            return true;
        } else if (action.equals("stop_scan")) {
            Log.d(TAG, LOG_PREFIX + "action stop_scan called");
            mCurrentAction = STOP_SCAN;
            unRegisterAdapterStateChanges();
            stopDeviceDiscovery();
            callbackContext.success();
            this.mBtEventsCallbackContext = null;
            return true;
        } else if (action.equals("getBondedDevices")) {
            this.mBtEventsCallbackContext = callbackContext;
            getBondedDevices();
            return true;
        } else {
            callbackContext.error("Invalid action");
            return false;
        }
    }

    private void initDeviceDiscovery() {
        Log.d(TAG, LOG_PREFIX + "initDeviceDiscovery called up");
        if (this.mBluetoothAdapter == null) {
            sendBtEvent(getJson("ERROR", "Bluetooth API is not available"), false);
            return;
        }
        if (!this.mBluetoothAdapter.isEnabled()) {
            Log.d(TAG, LOG_PREFIX + "Bluetooth is not enabled, enabling it...");
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            Log.d(TAG, LOG_PREFIX + "Calling Bluetooth enable activity");
            cordova.startActivityForResult(this, enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            Log.d(TAG, LOG_PREFIX + "Bluetooth is enabled");
            // Automatically cancel any previous discovery
            if (this.mBluetoothAdapter.isDiscovering()) {
                stopDeviceDiscovery();
            }

            if (Build.VERSION.SDK_INT >= 23) {
                if (cordova.hasPermission(Manifest.permission.ACCESS_FINE_LOCATION) && cordova.hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                    Log.d(TAG, LOG_PREFIX + "app has permissions ACCESS_FINE_LOCATION and/or ACCESS_COARSE_LOCATION");
                    this.startDiscovery();
                } else {
                    Log.d(TAG, LOG_PREFIX + "app doesn't have Manifest.permission.ACCESS_FINE_LOCATION and/or Manifest.permission.ACCESS_COARSE_LOCATION");
                    Log.d(TAG, LOG_PREFIX + "requesting permission ACCESS_FINE_LOCATION and/or ACCESS_COARSE_LOCATION");
                    cordova.requestPermissions(this,PERMNS_REQ_CODE, new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION,});
                }
                return;
            }
            this.startDiscovery();
        }
    }

    @Override
    public void onRequestPermissionResult(int requestCode, String[] permissions,
                                           int[] grantResults) throws JSONException {
        Log.d(TAG, LOG_PREFIX + "onRequestPermissionsResult called up");
        if (requestCode == PERMNS_REQ_CODE) {
            if (grantResults.length > 0) {
                boolean finePermnFlag = true;
                boolean coarsePermnFlag = true;
                int i=0;
                for (String per : permissions) {
                    if (per!=null && per.equals(Manifest.permission.ACCESS_COARSE_LOCATION) && grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        coarsePermnFlag = false;
                        Log.d(TAG, LOG_PREFIX + "following permission is DENIED");
                        Log.d(TAG, LOG_PREFIX + per);
                        sendBtEvent(getJson("PERMISSION", "Following permission is denied:" + per), false);
                    }else if (per!=null && per.equals(Manifest.permission.ACCESS_FINE_LOCATION) && grantResults[i] == PackageManager.PERMISSION_DENIED) {
                        finePermnFlag = false;
                        Log.d(TAG, LOG_PREFIX + "following permission is DENIED");
                        Log.d(TAG, LOG_PREFIX + per);
                        sendBtEvent(getJson("PERMISSION", "Following permission is denied:" + per), false);
                    }
                    i++;
                }
                if (finePermnFlag && coarsePermnFlag) {
                    Log.d(TAG, LOG_PREFIX + "COARSE and FINE Location Permissions GRANTED");
                    this.startDiscovery();
                }
            }
            return;
        }
    }


    private void stopDeviceDiscovery() {
        if (this.mBluetoothAdapter != null && this.mBluetoothAdapter.isDiscovering()) {
            this.mBluetoothAdapter.cancelDiscovery();
        }
    }

    public JSONObject getDeviceInfo(BluetoothDevice device) throws JSONException {
        JSONObject deviceInfo = new JSONObject();
        deviceInfo.put("address", device.getAddress());
        deviceInfo.put("name", device.getName());
        deviceInfo.put("paired", device.getBondState() == BluetoothDevice.BOND_BONDED);
        return deviceInfo;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        Log.d(TAG, LOG_PREFIX + "onActivityResult called up");
        if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_CANCELED) {
            if (mCurrentAction.equals(START_SCAN)) {
                Log.d(TAG, LOG_PREFIX + "User Cancelled Bluetooth enabling");
                sendBtEvent(getJson("ERROR", "User cancelled Bluetooth enabling"), false);
                return;
            }
        } else if (requestCode == REQUEST_ENABLE_BT && resultCode == Activity.RESULT_OK) {
            Log.d(TAG, LOG_PREFIX + "Bluetooth enabled");
            initDeviceDiscovery();
        }
    }

    public final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive called up");
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_STATE_CHANGED called");
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);

                // If there was an enable request pending, send the result
                if (state == BluetoothAdapter.STATE_ON) {
                    Log.d(TAG, LOG_PREFIX + "BluetoothAdapter.STATE_ON");
                    initDeviceDiscovery();
                } else if (state == BluetoothAdapter.STATE_OFF) {
                    Log.d(TAG, LOG_PREFIX + "BluetoothAdapter.STATE_OFF");
                    stopDeviceDiscovery();
                }
            } else if (action.equals(BluetoothAdapter.ACTION_DISCOVERY_STARTED)) {
                Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_DISCOVERY_STARTED called");
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_DISCOVERY_STARTED called");
                    sendBtEvent(getJson("DEVICE_DISCOVERY", "started"), true);
                    return;
                }
            } else if (action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)) {
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_DISCOVERY_FINISHED called");
                    sendBtEvent(getJson("DEVICE_DISCOVERY", "finished"), true);
                    return;
                }
            } else if (action.equals(BluetoothDevice.ACTION_FOUND)) {
                Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_FOUND called up");
                try {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    JSONObject deviceInfo = getDeviceInfo(device);

                    if (mCurrentAction.equals(START_SCAN)) {
                        Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_FOUND called up");
                        Log.d(TAG, LOG_PREFIX + "deviceInfo:"+deviceInfo.toString());
                        sendBtEvent(getJson("DEVICE_FOUND", deviceInfo.toString()), true);
                        return;
                    }
                } catch (JSONException e) {
                    if (mCurrentAction.equals(START_SCAN)) {
                        Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_FOUND exception called up:"+e.toString());
                        sendBtEvent(getJson("DEVICE_FOUND_ERROR", e.toString()), true);
                        return;
                    }
                }
            }
        }
    };

    public void startDiscovery() {
        if (mCurrentAction.equals(START_SCAN)) {
            Log.d(TAG, LOG_PREFIX + "startDiscovery called");
            cordova.getThreadPool().execute(() -> {
                if (mBluetoothAdapter != null)
                    mBluetoothAdapter.startDiscovery();
            });
            return;
        }
    }

    private void registerAdapterStateChanges() {
        Log.d(TAG, LOG_PREFIX + "registerAdapterStateChanges called");
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        filter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        cordova.getActivity().registerReceiver(this.mReceiver, filter);
        //LocalBroadcastManager.getInstance(cordova.getActivity()).registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterAdapterStateChanges() {
        Log.d(TAG, LOG_PREFIX + "unRegisterAdapterStateChanges called");
        cordova.getActivity().unregisterReceiver(this.mReceiver);
        //LocalBroadcastManager.getInstance(cordova.getActivity()).unregisterReceiver(this.mReceiver);
    }

    private void getBondedDevices() {
        Log.d(TAG, LOG_PREFIX + "getBondedDevices called");
        if (this.mBluetoothAdapter == null) {
            sendBtEvent(getJson("ERROR", "Bluetooth API is not available"), false);
            return;
        }
        Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
        try {
            for (BluetoothDevice device : devices) {
                sendBtEvent(getJson("BONDED_DEVICE", getDeviceInfo(device).toString()), true);
            }
            this.mBtEventsCallbackContext = null;
        } catch (JSONException e) {
            sendBtEvent(getJson("ERROR", e.getMessage()), false);
        }
    }

    private JSONObject getJson(String eventType, String eventValue) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("eventType", eventType);
            obj.put("eventValue", eventValue);
        } catch (JSONException e) {
            Log.d(TAG, LOG_PREFIX + e.getMessage(), e);
        }
        return obj;
    }

    private void sendBtEvent(JSONObject info, boolean keepCallback) {
        Log.d(TAG, LOG_PREFIX + "sendBtEvent called");
        if (this.mBtEventsCallbackContext != null) {
            Log.d(TAG, LOG_PREFIX + "mBtEventsCallbackContext is not null, firing BluetoothEvent");
            PluginResult result = new PluginResult(PluginResult.Status.OK, info);
            result.setKeepCallback(keepCallback);
            this.mBtEventsCallbackContext.sendPluginResult(result);
        } else {
            Log.d(TAG, LOG_PREFIX + "mBtEventsCallbackContext is null, unable to fire BluetoothEvent");
        }
        // webView.postMessage("networkconnection", type);
    }
}