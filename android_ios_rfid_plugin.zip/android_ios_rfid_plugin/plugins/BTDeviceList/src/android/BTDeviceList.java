package com.techm.btdevicelist;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.util.Log;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaArgs;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class BTDeviceList extends CordovaPlugin {

    private static final String TAG = "BTDeviceListPlugin";
    private static final String LOG_PREFIX = "PLUGIN: ";
    public static final int REQUEST_ENABLE_BT = 1773;
    public static final int REQUEST_DISCOVERABLE_BT = 1885;
    public static final int START_DISCOVERY_REQ_CODE = 1997;

    public BluetoothAdapter mBluetoothAdapter = null;
    public ConcurrentHashMap<Integer, CallbackContext> mContextForActivity = new ConcurrentHashMap<Integer, CallbackContext>();
    public ConcurrentHashMap<Integer, CallbackContext> mContextForPermission = new ConcurrentHashMap<Integer, CallbackContext>();
    public CallbackContext mContextForAdapterStateChanged = null;
    public CallbackContext mContextForDeviceAdded = null;
    //public boolean mDeviceAddedRegistered = false;
    public int mPreviousScanMode = BluetoothAdapter.SCAN_MODE_NONE;
    public static final String START_SCAN = "start_scan";
    private String mCurrentAction = "";
    private CallbackContext mBtEventsCallbackContext;
    private static final String STOP_SCAN = "stop_scan";

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);
        this.mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        this.mBtEventsCallbackContext = null;
    }

    @Override
    public boolean execute(String action, CordovaArgs args, final CallbackContext callbackContext) {

        if (this.mBluetoothAdapter == null) {
            callbackContext.error("Device does not support Bluetooth");
            return false;
        }
        if (action.equals("start_scan")) {
            Log.d(TAG, LOG_PREFIX + "action init device discovery called");
            mCurrentAction = START_SCAN;
            this.mBtEventsCallbackContext = callbackContext;
            registerAdapterStateChanges();
            initDeviceDiscovery();
            return true;
        } else if (action.equals("stop_scan")) {
            this.mBtEventsCallbackContext = callbackContext;
            unRegisterAdapterStateChanges();
            stopDeviceDiscovery();
            return true;
        } else if (action.equals("getBondedDevices")) {
            this.mBtEventsCallbackContext = callbackContext;
            getBondedDevices();
            return true;
        } else {
            callbackContext.error("Invalid action");
            return false;
        }
    }

    private void stopDeviceDiscovery() {
        if (this.mBluetoothAdapter != null && this.mBluetoothAdapter.isDiscovering()) {
            if (this.mBluetoothAdapter.cancelDiscovery() && this.mBtEventsCallbackContext != null) {
                this.mBtEventsCallbackContext.success();
            } else if (this.mBtEventsCallbackContext != null) {
                this.mBtEventsCallbackContext.error(0);
            }
        } else if (this.mBtEventsCallbackContext != null) {
            this.mBtEventsCallbackContext.success();
        }
        this.mBtEventsCallbackContext = null;
    }

    public JSONObject getDeviceInfo(BluetoothDevice device) throws JSONException {
        JSONObject deviceInfo = new JSONObject();
        deviceInfo.put("address", device.getAddress());
        deviceInfo.put("name", device.getName());
        deviceInfo.put("paired", device.getBondState() == BluetoothDevice.BOND_BONDED);
        return deviceInfo;
    }

    public void prepareActivity(Intent intent, int requestCode) {
        if (this.mContextForActivity.containsKey(requestCode)) {
            if (mCurrentAction.equals(START_SCAN)) {
                Log.d(TAG, LOG_PREFIX + "Attempted to start the same activity twice");
                sendBtEvent(getJson("EnableBluetoothActivity", "Attempted to start the same activity twice"), true);
                return;
            }
            if (mBtEventsCallbackContext != null) {
                mBtEventsCallbackContext.error("Attempted to start the same activity twice");
            }
            return;
        }
        // Store the callbackContext, in order to send the result once the activity has been completed
        if (mBtEventsCallbackContext != null) {
            this.mContextForActivity.put(requestCode, mBtEventsCallbackContext);
        }

        // Store the callbackContext, in order to send the result once the activity has been completed
        Log.d(TAG, LOG_PREFIX + "Calling BT enable activity");
        cordova.startActivityForResult(this, intent, requestCode);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        CallbackContext callbackContext = this.mContextForActivity.remove(requestCode);

        if (callbackContext != null) {
            if (resultCode == Activity.RESULT_CANCELED) {
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "User Cancelled BT enable");
                    sendBtEvent(getJson("EnableBluetoothActivity", "user cancelled BT enable"), true);
                    return;
                }
                callbackContext.error(0);
            } else {
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "BT Adapter cancelling device discovery");
                    // Automatically cancel any previous discovery
                    if (this.mBluetoothAdapter.isDiscovering()) {
                        this.mBluetoothAdapter.cancelDiscovery();
                    }

                    if (cordova.hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                        Log.d(TAG, LOG_PREFIX + "has Manifest.permission.ACCESS_COARSE_LOCATION");
                        this.startDiscovery();
                    } else {
                        Log.d(TAG, LOG_PREFIX + "requesting permission ACCESS_COARSE_LOCATION");
                        this.getPermission(callbackContext, START_DISCOVERY_REQ_CODE, Manifest.permission.ACCESS_COARSE_LOCATION);
                    }
                    return;
                }
                //callbackContext.success();
            }
        } else {
            // TO DO -- This may be a bug on the JavaScript side, as we get here only if the
            // activity has been started twice, before waiting the completion of the first one.
            Log.e(TAG, "BUG: onActivityResult -- (callbackContext == null)");
            sendBtEvent(getJson("EnableBluetoothActivity", "activity has been started twice, before waiting the completion of the first one."), true);
        }
    }

    public final BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            PluginResult pluginResult;

            Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive called");
            if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
                Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_STATE_CHANGED called");
                int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, -1);

                // If there was an enable request pending, send the result
                if (state == BluetoothAdapter.STATE_ON) {
                    registerAdapterStateChanges();
                    initDeviceDiscovery();
                } else if (state == BluetoothAdapter.STATE_OFF) {
                    stopDeviceDiscovery();
                    unRegisterAdapterStateChanges();
                }
            } else if (action.equals(BluetoothAdapter.ACTION_DISCOVERY_STARTED)) {
                Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_DISCOVERY_STARTED called");
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_DISCOVERY_STARTED called in if()");
                    sendBtEvent(getJson("DeviceDiscovery", "started"), true);
                    return;
                }
            } else if (action.equals(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)) {
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_DISCOVERY_FINISHED called");
                    sendBtEvent(getJson("DeviceDiscovery", "finished"), true);
                    return;
                }
            } else if (action.equals(BluetoothDevice.ACTION_FOUND)) {
                Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_FOUND called");
                try {
                    BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    JSONObject deviceInfo = getDeviceInfo(device);

                    if (mCurrentAction.equals(START_SCAN)) {
                        Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_FOUND called in if()");
                        sendBtEvent(getJson("DEVICE_FOUND", deviceInfo.toString()), true);
                        return;
                    }
                } catch (JSONException e) {
                    if (mCurrentAction.equals(START_SCAN)) {
                        Log.d(TAG, LOG_PREFIX + "BroadcastReceiver onReceive ACTION_FOUND Json exception called");
                        sendBtEvent(getJson("DEVICE_FOUND_ERROR", e.toString()), true);
                        return;
                    }
                }
            }
        }
    };

    public void startDiscovery() {
        if (mCurrentAction.equals(START_SCAN)) {
            Log.d(TAG, LOG_PREFIX + "startDiscovery called");
            cordova.getThreadPool().execute(() -> {
                mBluetoothAdapter.startDiscovery();
            });
            return;
        }
    }

    public void getPermission(CallbackContext callbackContext, int requestCode, String permission) {
        // If there already is another permission request with this request code, call the error callback in order
        // to notify that the request has been cancelled
        if (this.mContextForPermission.containsKey(requestCode)) {
            if (mCurrentAction.equals(START_SCAN)) {
                Log.d(TAG, LOG_PREFIX + "getPermission called: Attempted to request the same permission twice");
                sendBtEvent(getJson("Permission", "Attempted to request the same permission twice"), true);
                return;
            }
            callbackContext.error("Attempted to request the same permission twice");
            return;
        }

        // Store the callbackContext, in order to send the result once the activity has been completed
        this.mContextForPermission.put(requestCode, callbackContext);

        Log.d(TAG, LOG_PREFIX + "getPermission called: requesting Permission");
        cordova.requestPermission(this, requestCode, permission);
    }

    @Override
    public void onRequestPermissionResult(int requestCode, String[] permissions, int[] grantResults) throws JSONException {
        CallbackContext callbackContext = this.mContextForPermission.remove(requestCode);

        Log.d(TAG, LOG_PREFIX + "Permission Granted");
        if (requestCode == START_DISCOVERY_REQ_CODE) {
            if ((grantResults.length > 0) && (grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                Log.d(TAG, LOG_PREFIX + "getPermission starting device discovery");
                this.startDiscovery();
            } else {
                if (mCurrentAction.equals(START_SCAN)) {
                    Log.d(TAG, LOG_PREFIX + "Permission not granted");
                    sendBtEvent(getJson("Permission", "Permission not granted"), false);
                    return;
                }
                callbackContext.error(0);
            }
        }
    }

	/*private ActivityResultLauncher<String> mPermissionResult = registerForActivityResult(
			new ActivityResultContracts.RequestPermission(),
			new ActivityResultCallback<Boolean>() {
				@Override
				public void onActivityResult(Boolean result) {
					if(result) {
						Log.e(TAG, "onActivityResult: PERMISSION GRANTED");
					} else {
						Log.e(TAG, "onActivityResult: PERMISSION DENIED");
					}
				}
			});
	mPermissionResult.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION);*/

    private void registerAdapterStateChanges() {
        Log.d(TAG, LOG_PREFIX + "registerAdapterStateChanges called");
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothAdapter.ACTION_STATE_CHANGED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        filter.addAction(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        cordova.getActivity().registerReceiver(this.mReceiver, filter);
        //LocalBroadcastManager.getInstance(cordova.getActivity()).registerReceiver(this.mReceiver, filter);
    }

    private void unRegisterAdapterStateChanges() {
        Log.d(TAG, LOG_PREFIX + "unRegisterAdapterStateChanges called");
        cordova.getActivity().unregisterReceiver(this.mReceiver);
        //LocalBroadcastManager.getInstance(cordova.getActivity()).unregisterReceiver(this.mReceiver);
    }

    private void getBondedDevices(){
        Log.d(TAG, LOG_PREFIX + "getBondedDevices called");
        if (this.mBluetoothAdapter == null) {
            sendBtEvent(getJson("ERROR", "Bluetooth API is not available"), false);
            return;
        }
        Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
        try {
            for (BluetoothDevice device : devices) {
                sendBtEvent(getJson("BONDED_DEVICE", getDeviceInfo(device).toString()), true);
            }
            this.mBtEventsCallbackContext = null;
        } catch (JSONException e) {
            sendBtEvent(getJson("ERROR", e.getMessage()), false);
        }
    }

    private void initDeviceDiscovery() {
        if (this.mBluetoothAdapter == null) {
            sendBtEvent(getJson("ERROR", "Bluetooth API is not available"), false);
            return;
        }
        if (!this.mBluetoothAdapter.isEnabled()) {
            Log.d(TAG, LOG_PREFIX + "BT is not enabled, enabling it...");
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            this.prepareActivity(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            Log.d(TAG, LOG_PREFIX + "BT Adapter cancelling device discovery");
            // Automatically cancel any previous discovery
            if (this.mBluetoothAdapter.isDiscovering()) {
                this.mBluetoothAdapter.cancelDiscovery();
            }

            Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
            try {
                for (BluetoothDevice device : devices) {
                    sendBtEvent(getJson("BONDED_DEVICE", getDeviceInfo(device).toString()), true);
                }
            } catch (JSONException e) {
                sendBtEvent(getJson("ERROR", e.getMessage()), false);
            }

            if (cordova.hasPermission(Manifest.permission.ACCESS_COARSE_LOCATION)) {
                Log.d(TAG, LOG_PREFIX + "app has Manifest.permission.ACCESS_COARSE_LOCATION");
                this.startDiscovery();
            } else {
                Log.d(TAG, LOG_PREFIX + "requesting permission ACCESS_COARSE_LOCATION");
                this.getPermission(mBtEventsCallbackContext, START_DISCOVERY_REQ_CODE, Manifest.permission.ACCESS_COARSE_LOCATION);
            }
        }
    }

    private JSONObject getJson(String eventType, String eventValue) {
        JSONObject obj = new JSONObject();
        try {
            obj.put("eventType", eventType);
            obj.put("eventValue", eventValue);
        } catch (JSONException e) {
            Log.d(TAG, LOG_PREFIX + e.getMessage(), e);
        }
        return obj;
    }

    private void sendBtEvent(JSONObject info, boolean keepCallback) {
        Log.d(TAG, LOG_PREFIX + "sendBtEvent called");
        if (this.mBtEventsCallbackContext != null) {
            Log.d(TAG, LOG_PREFIX + "mBtEventsCallbackContext is not null, firing BluetoothEvent");
            PluginResult result = new PluginResult(PluginResult.Status.OK, info);
            result.setKeepCallback(keepCallback);
            this.mBtEventsCallbackContext.sendPluginResult(result);
        } else {
            Log.d(TAG, LOG_PREFIX + "mBtEventsCallbackContext is null, unable to fire BluetoothEvent");
        }
        // webView.postMessage("networkconnection", type);
    }
}