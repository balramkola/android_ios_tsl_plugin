module.exports = {

    initRfidReader: function (libName, successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'RfidPlugin', 'initRfidReader', [libName]);
    },

    readerEvents: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'RfidPlugin', 'startReaderEvents', []);
    },

    stopReaderEvents: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'RfidPlugin', 'stopReaderEvents', []);
    },

    connect: function (readerAddress, success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'connect', [readerAddress]);
    },

    stopConnEvents: function (success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'stopConnEvents', []);
    },

    disconnect: function (success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'disconnect', []);
    },

    enableTagScan: function (value, success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'enableTagScan', [value]);
    },

    enableBarcodeScan: function (value, success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'enableBarcodeScan', [value]);
    },

    scanTags: function (success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'scanTags', []);
    },

    getConnectionStatus: function (success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'getConnectionStatus', []);
    },

    getReaderProperties: function (success, error) {
        cordova.exec(success, error, 'RfidPlugin', 'getReaderProperties', []);
    }
};
