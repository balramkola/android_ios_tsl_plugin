package com.techm.rfidplugin.factory;

import com.techm.rfidplugin.tsl.main.TslHandler;
import com.techm.rfidplugin.zebra.main.ZebraHandler;

public class PluginFactory {
    public static IRFIDHandler getInstance(String pluginName) {
        if (pluginName == null || pluginName.isEmpty()) {
            return null;
        }
        if (pluginName.equalsIgnoreCase("zebra")) {
            return new ZebraHandler();
        } else if (pluginName.equalsIgnoreCase("tsl")) {
            return new TslHandler();
        }
        return null;
    }
}
