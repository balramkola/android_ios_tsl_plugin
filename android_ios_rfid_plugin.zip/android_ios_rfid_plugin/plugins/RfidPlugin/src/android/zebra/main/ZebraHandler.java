package com.techm.rfidplugin.zebra.main;

import android.content.Context;
import android.util.Log;

import com.techm.rfidplugin.factory.IRFIDHandler;
import com.techm.rfidplugin.factory.IRFIDHandlerCallback;
import com.techm.rfidplugin.zebra.comm.ConnectionState;
import com.techm.rfidplugin.zebra.comm.Connector;
import com.techm.rfidplugin.zebra.rfid.InventoryModel;
import com.techm.rfidplugin.zebra.utilities.Util;

import org.json.JSONObject;


public class ZebraHandler implements IRFIDHandler {

    private static final String LOG_TAG = ZebraHandler.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";
    private static final String EVENT_TYPE = "GENERIC";
    private static final String EVENT_READER_INFO = "READER_INFO";
    private static final String EVENT_TYPE_ERROR = "ERROR";
    private Context mActivityContext = null;
    private Context mAppContext = null;
    private boolean mEnableRfid;
    private boolean mEnableBarcode;
    private boolean isLibInitialized = false;

    //Zebra
    // All of the reader inventory tasks are handled by this class
    private InventoryModel mInventoryModel = null;
    private Connector mConnector = null;
    private IRFIDHandlerCallback mRfidHandlerCallback = null;

    @Override
    public void initLib(Context activityContext) {
        Log.d(LOG_TAG, LOG_PREFIX + "initializing the Zebra library");
        sendLibEvent("initializing the Zebra library");

        if (null == activityContext) {
            sendLibEvent("Unable to get Activity Context");
            Log.d(LOG_TAG, LOG_PREFIX + "Unable to get Activity Context");
            return;
        }
        mActivityContext = activityContext;
        mAppContext = activityContext.getApplicationContext();
        if (mAppContext == null) {
            Log.d(LOG_TAG, LOG_PREFIX + "Unable to get Application Context");
            sendLibEvent("Unable to get Application Context");
            return;
        }

        Log.d(LOG_TAG, LOG_PREFIX + "Zebra Library Initialized");
        sendLibEvent(LIB_INITIALIZED);
        isLibInitialized = true;
    }

    @Override
    public void setEnableRfid(boolean value) {
        mEnableRfid = value;
        if (mInventoryModel != null) {
            mInventoryModel.setRfidEnabled(value);
        }
    }

    @Override
    public void setEnableBarcode(boolean value) {
        Log.d(LOG_TAG, LOG_PREFIX + "Barcode feature is not available on Zebra device");
        setErrorEvent("Barcode feature in not available");
    }

    @Override
    public void onPause() {
        //TODO
    }

    @Override
    public void onResume() {
        //TODO
    }

    @Override
    public void connect(String macAddress) {
        Log.d(LOG_TAG, LOG_PREFIX + "connect(macAddress) called");
        if (!isLibInitialized) {
            setErrorEvent("Zebra library is not initialized");
            Log.d(LOG_TAG, LOG_PREFIX + "Zebra library is not initialized");
            return;
        }
        if (mConnector == null) {
            mConnector = new Connector(mActivityContext);
        }
        mConnector.setConnStateCallback(new Connector.IConnStateChange() {
            @Override
            public void onConnStateChange(ConnectionState connectionState) {
                onConnStateArrival(connectionState);
            }

            @Override
            public void onError(String errMsg) {
                sendConnErr(errMsg);
            }
        });
        mConnector.connect(macAddress);
    }

    @Override
    public void disconnect() {
        Log.d(LOG_TAG, LOG_PREFIX + "disconnect() called");
        if (mConnector != null) {
            mConnector.disconnect();
            mConnector.setConnStateCallback(null);
        }

        if (mInventoryModel != null) {
            //unregister for rfid tag and barcode events
            mInventoryModel.setRfidEnabled(false);
            Log.d(LOG_TAG, LOG_PREFIX + "unregistering for rfid tag events");
            //stop listening to events from InventoryModel
            mInventoryModel.setInventoryCallback(null);
            mInventoryModel = null;
        }
    }


//    private class AsyncZebrainit extends AsyncTask<String[], Void, Void> {
//        @Override
//        protected Void doInBackground(String[]... params) {
//
//            //Zebra
//            // Ensure the shared instance of AsciiCommander exists
//
//            //Create a (custom) model and configure its commander and handler
//            mInventoryModel = new InventoryModel();
//            //mInventoryModel.setCommander(getCommander());
//            //mInventoryModel.setCallback(ZebraHandler.this);
//            //mInventoryModel.setEnabled(false);
//
//            // Remember if the pause/resume was caused by ReaderManager - this will be cleared when ReaderManager.onResume() is called
//            //boolean readerManagerDidCauseOnPause = ReaderManager.sharedInstance().didCauseOnPause();
//
//            // The ReaderManager needs to know about Activity lifecycle changes
//            ReaderManager.sharedInstance().onResume();
//
//            return null;
//        }
//    }

    @Override
    public synchronized void scanTags() {
        Log.d(LOG_TAG, LOG_PREFIX + "scanTags() called");
        if (mInventoryModel != null) {
            mInventoryModel.scanTags();
        } else {
            setErrorEvent("Device is not connected");
        }
    }

    private void onConnected() {
        //if needed call update config params and then execute update config command
        //mInventoryModel.updateReaderConfigCmd(configParams);
        //TODO run in background thread
        // start
        Log.d(LOG_TAG, LOG_PREFIX + "onConnected() called");
        mInventoryModel = new InventoryModel();
        mInventoryModel.setInventoryCallback(new InventoryModel.IinventoryModelCallback() {
            @Override
            public void onTagDetectedEvent(JSONObject tagInfoJson) {
                Log.d(LOG_TAG, LOG_PREFIX + "onTagDetectedEvent() called");
                sendInventoryEvent(tagInfoJson);
            }

            @Override
            public void onErrorEvent(JSONObject errJson) {
                Log.d(LOG_TAG, LOG_PREFIX + "onErrorEvent() called");
                sendInventoryEvent(errJson);
            }
        });

        mInventoryModel.setReader(mConnector.getReader());
        mInventoryModel.setRfidEnabled(mEnableRfid);
        mInventoryModel.setReaderConfig();
        //TODO end
    }

    private void onDisconnected() {
        Log.d(LOG_TAG, LOG_PREFIX + "onDisconnected() called");
        //TODO handle on Reader disconnection state

//        if (null != mInventoryModel) {
//            mInventoryModel.setInventoryCallback(null);
//            mInventoryModel = null;
//        }
    }

    private void onConnStateArrival(ConnectionState state) {

        switch (state) {
            case CONNECTED:
                onConnected();
                sendConnStateEvent(state.name());
                if (null != mConnector.getReader()) {
                    Log.d(LOG_TAG, LOG_PREFIX + "connected to reader:" + mConnector.getReader().getHostName());
                }
                break;
            case CONNECTING:
                if (null != mConnector.getReader()) {
                    Log.d(LOG_TAG, LOG_PREFIX + "connecting to reader:" + mConnector.getReader().getHostName());
                }
                break;
            case DISCONNECTED:
            case LOST:
                sendConnStateEvent(state.name());
                onDisconnected();
                if (null != mConnector.getReader()) {
                    Log.d(LOG_TAG, LOG_PREFIX + "Reader disconnected:" + mConnector.getReader().getHostName());
                }
                break;
            default:
                sendConnErr(state.name());
                Log.d(LOG_TAG, LOG_PREFIX + "Something went wrong");
        }
    }

    protected JSONObject getFormattedEvent(String eventType, String eventValue) {
        return Util.getJson(eventType, eventValue);
    }

    @Override
    public void getReaderProps() {
        Log.d(LOG_TAG, LOG_PREFIX + "getReaderProps() called :");
        if (null != mConnector) {
            JSONObject readProps = mConnector.getReaderInfo();
            if (null != mRfidHandlerCallback) {
                if (readProps != null) {
                    if (readProps.length() > 0) {
                        mRfidHandlerCallback.onReaderProps(Util.getJson(EVENT_READER_INFO, readProps.toString()));
                    } else {
                        mRfidHandlerCallback.onReaderProps(Util.getJson(EVENT_TYPE_ERROR, "Unable to get Reader Info"));
                    }
                }
            }
        } else {
            Log.d(LOG_TAG, LOG_PREFIX + "getReaderProps(), null == mConnector");
            if (null != mRfidHandlerCallback) {
                mRfidHandlerCallback.onReaderProps(Util.getJson(EVENT_TYPE_ERROR, ConnectionState.DISCONNECTED.name()));
            }
        }
    }

    @Override
    public String getConnStatus() {
        if (mConnector != null) {
            return mConnector.getReaderConnState().name();
        }
        return "Unable to get connection status";
    }

    protected void setEvent(String eventValue) {
        Log.d(LOG_TAG, LOG_PREFIX + "setEvent called :" + eventValue);
        if (mRfidHandlerCallback != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "getFormattedEvent(EVENT_TYPE, eventValue):" + getFormattedEvent(EVENT_TYPE, eventValue));
            mRfidHandlerCallback.onEvent(getFormattedEvent(EVENT_TYPE, eventValue));
        }
    }

    protected void setErrorEvent(String eventValue) {
        if (mRfidHandlerCallback != null) {
            mRfidHandlerCallback.onEvent(getFormattedEvent(EVENT_TYPE_ERROR, eventValue));
        }
    }

    private void sendConnStateEvent(String connectionState) {
        if (null != mRfidHandlerCallback) {
            mRfidHandlerCallback.onConnEvent(connectionState);
        }
    }

    private void sendLibEvent(String eventValue) {
        Log.d(LOG_TAG, LOG_PREFIX + "sendLibEvent called :" + eventValue);
        if (mRfidHandlerCallback != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "Lib Event:" + eventValue);
            mRfidHandlerCallback.onLibEvent(eventValue);
        }
    }

    private void sendConnErr(String error) {
        if (null != mRfidHandlerCallback) {
            mRfidHandlerCallback.onConnEvent(error);
        }
    }

    private void sendInventoryEvent(JSONObject eventJson) {
        if (null != mRfidHandlerCallback) {
            mRfidHandlerCallback.onInventoryEvent(eventJson);
        }
    }

    @Override
    public void setCallback(IRFIDHandlerCallback rfidHandlerCallback) {
        mRfidHandlerCallback = rfidHandlerCallback;
    }
}

