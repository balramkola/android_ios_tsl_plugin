package com.techm.rfidplugin.tsl.rfid;

import android.util.Log;

import com.techm.rfidplugin.tsl.utilities.Util;
import com.uk.tsl.rfid.asciiprotocol.AsciiCommander;
import com.uk.tsl.rfid.asciiprotocol.DeviceProperties;
import com.uk.tsl.rfid.asciiprotocol.commands.BarcodeCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.FactoryDefaultsCommand;
import com.uk.tsl.rfid.asciiprotocol.commands.InventoryCommand;
import com.uk.tsl.rfid.asciiprotocol.enumerations.TriState;
import com.uk.tsl.rfid.asciiprotocol.responders.IBarcodeReceivedDelegate;
import com.uk.tsl.rfid.asciiprotocol.responders.ICommandResponseLifecycleDelegate;
import com.uk.tsl.rfid.asciiprotocol.responders.ITransponderReceivedDelegate;
import com.uk.tsl.rfid.asciiprotocol.responders.TransponderData;
import com.uk.tsl.utils.HexEncoding;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class InventoryModel {

    private static final String LOG_TAG = InventoryModel.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";
    private static final String EVENT_TYPE_TAG = "INVENTORY_TAG";
    private static final String EVENT_TYPE_BARCODE = "INVENTORY_BARCODE";
    private static final String EVENT_TYPE_ERROR = "ERROR";

    private boolean mAnyTagSeen;
    private boolean mRfidEnabled;
    private boolean mBarcodeEnabled;

    // The command to used as a responder to capture incoming inventory responses
    private InventoryCommand mTagResponder;
    // The command used to issue commands
    private InventoryCommand mReaderConfigCmd;
    // The command to used as a responder to capture incoming barcode responses
    private BarcodeCommand mBarcodeResponder;
    private AsciiCommander mCommander;
    private IinventoryModelCallback mInventoryCallback = null;
    private boolean mIsReaderBusy = false;

    //enable it to get tag info after it got detected by TSL reader,
    //if its disabled, Reader detects tag but tag info is not passed to the callback(InventoryResponder)
    public void setRfidEnabled(boolean state) {
        boolean oldState = mRfidEnabled;
        mRfidEnabled = state;

        // Update the commander for state changes
        if (oldState != state) {
            if (mRfidEnabled) {
                Log.d(LOG_TAG, LOG_PREFIX + "adding InventoryResponder(RFID) to commander to receive detected RFID tags info");
                // Listen for transponders/RFID tags detections
                getCommander().addResponder(mTagResponder);
            } else {
                Log.d(LOG_TAG, LOG_PREFIX + "removing InventoryResponder(RFID) from commander");
                // Stop listening for transponders
                getCommander().removeResponder(mTagResponder);
            }
        }
    }

    //enable it to get barcode info after it got detected by TSL reader,
    //if its disabled, Reader detects barcode but barcode info is not passed to the callback(BarcodeResponder)
    public void setBarcodeEnabled(boolean state) {
        boolean oldState = mBarcodeEnabled;
        mBarcodeEnabled = state;

        // Update the commander for state changes
        if (oldState != state) {
            if (mBarcodeEnabled) {
                Log.d(LOG_TAG, LOG_PREFIX + "adding BarcodeResponder(Barcode) to commander to receive detected barcode info");
                // Listen for barcodes
                getCommander().addResponder(mBarcodeResponder);
            } else {
                Log.d(LOG_TAG, LOG_PREFIX + "removing BarcodeResponder(Barcode) from commander");
                // Stop listening for barcodes
                getCommander().removeResponder(mBarcodeResponder);
            }
        }
    }

    private AsciiCommander getCommander() {
        return mCommander;
    }

    public void setCommander(AsciiCommander commander) {
        mCommander = commander;
    }

    public InventoryModel() {
        Log.d(LOG_TAG, LOG_PREFIX + "called InventoryModel()");

        Log.d(LOG_TAG, LOG_PREFIX + "configuring InventoryResponder object");
        // Use an InventoryCommand as a responder to capture all incoming inventory responses
        mTagResponder = new InventoryCommand();

        // Also capture the responses that were not from App commands
        mTagResponder.setCaptureNonLibraryResponses(true);

        // Notify when each transponder/tag is seen
        Log.d(LOG_TAG, LOG_PREFIX + "notify when each transponder/tag is seen");
        mTagResponder.setTransponderReceivedDelegate(new ITransponderReceivedDelegate() {

            int mTagsSeen = 0;

            @Override
            public void transponderReceived(TransponderData transponder, boolean moreAvailable) {
                mAnyTagSeen = true;
                Log.d(LOG_TAG, LOG_PREFIX + "detected RFID tag");
                Map<String, String> map = new HashMap<String, String>();
                map.put("EPC", transponder.getEpc());
                String tidMessage = transponder.getTidData() == null ? "" : HexEncoding.bytesToString(transponder.getTidData());
                map.put("TidData", tidMessage);
                map.put("Rssi", "" + transponder.getRssi());
                String readData = transponder.getReadData() == null ? "" : HexEncoding.bytesToString(transponder.getReadData());
                map.put("ReadData", readData);
                map.put("AccessErrorCode", "" + transponder.getAccessErrorCode());
                map.put("Timestamp", "" + transponder.getTimestamp());
                //map.put("CRC",""+transponder.getCrc());
                map.put("PC",""+transponder.getPc());
                //map.put("Index",""+transponder.getIndex());
                //map.put("Phase",""+transponder.getPhase());
                //map.put("ChannelFrequency",""+transponder.getChannelFrequency());
                JSONObject tagInfo = new JSONObject(map);
                Log.d(LOG_TAG, LOG_PREFIX + "Tag info:" + tagInfo.toString());
                sendTagEvent(tagInfo.toString());
                //String tidMessage = transponder.getTidData() == null ? "" : HexEncoding.bytesToString(transponder.getTidData());
                //String infoMsg = String.format(Locale.US, "\nRSSI: %d  PC: %04X  CRC: %04X", transponder.getRssi(), transponder.getPc(), transponder.getCrc());
                //Log.d(LOG_TAG, LOG_PREFIX + "detected RFID tag EPC:" + transponder.getEpc());
                //sendTagEvent("EPC: " + transponder.getEpc() + infoMsg + "\nTID: " + tidMessage + "\n# " + mTagsSeen);
                mTagsSeen++;
                if (!moreAvailable) {
                    Log.d(LOG_TAG, LOG_PREFIX + "Total TagCount:" + String.format(" %s", mTagsSeen));
                }
            }
        });

        mTagResponder.setResponseLifecycleDelegate(new ICommandResponseLifecycleDelegate() {

            //scan ended
            @Override
            public void responseEnded() {
                Log.d(LOG_TAG, LOG_PREFIX + "ICommandResponseLifecycleDelegate() responseEnded() called");
                if (!mAnyTagSeen && getReaderConfigCmd().getTakeNoAction() != TriState.YES) {
                    sendTagEvent("No transponders/tags seen");
                }
                getReaderConfigCmd().setTakeNoAction(TriState.NO);
                mIsReaderBusy = false;
            }

            //scan started
            @Override
            public void responseBegan() {
                mAnyTagSeen = false;
                mIsReaderBusy = true;
                Log.d(LOG_TAG, LOG_PREFIX + "ICommandResponseLifecycleDelegate() responseBegan() called");
            }
        });

        // This command is used to configure barcode scanning
        Log.d(LOG_TAG, LOG_PREFIX + "configuring BarcodeResponder object");
        mBarcodeResponder = new BarcodeCommand();
        mBarcodeResponder.setCaptureNonLibraryResponses(true);
        mBarcodeResponder.setUseEscapeCharacter(TriState.YES);
        mBarcodeResponder.setIncludeDateTime(TriState.YES);
        //to capture barcode responses
        mBarcodeResponder.setBarcodeReceivedDelegate(new IBarcodeReceivedDelegate() {
            @Override
            public void barcodeReceived(String barcode) {
                Log.d(LOG_TAG, LOG_PREFIX + "detected barcode:" + barcode);
                sendBarcodeEvent("BarCode:" + barcode);
            }
        });
    }

    //
    // Reset the reader configuration to default command values
    //
    public void resetDevice() {
        if (getCommander().isConnected()) {
            Log.d(LOG_TAG, LOG_PREFIX + "resetting TSL RFID reader");
            FactoryDefaultsCommand fdCommand = new FactoryDefaultsCommand();
            fdCommand.setResetParameters(TriState.YES);
            getCommander().executeCommand(fdCommand);
        }
    }

    //
    // Update the reader configuration from the command
    // Call this after each change to the model's command
    //TODO run this command using RxJava in the background
    public void setReaderConfig() {
        if (getCommander().isConnected()) {
            Log.d(LOG_TAG, LOG_PREFIX + "updating the reader configuration from the command");
            boolean rfidEnabled = mRfidEnabled;
            boolean barcodeEnabled = mBarcodeEnabled;
            setRfidEnabled(false);
            setBarcodeEnabled(false);
            getReaderConfigCmd().setTakeNoAction(TriState.YES);
            Log.d(LOG_TAG, LOG_PREFIX + "executing reader configuration command");
            resetDevice();
            getCommander().executeCommand(getReaderConfigCmd());
            Log.d(LOG_TAG, LOG_PREFIX + "done executing reader configuration command");
            //getReaderConfigCmd().setTakeNoAction(TriState.NO);
            setRfidEnabled(rfidEnabled);
            setBarcodeEnabled(barcodeEnabled);
        }
    }

    // This is the command that will be used to perform configuration changes
    private InventoryCommand getReaderConfigCmd() {
        if (mReaderConfigCmd != null) {
            return mReaderConfigCmd;
        }
        Log.d(LOG_TAG, LOG_PREFIX + "configuring InventoryCommand");
        //This is initial configuration, use updateReaderConfigCmd if user wants to change configuration
        mReaderConfigCmd = new InventoryCommand();
        //mReaderConfigCmd.setResetParameters(TriState.YES);
        // Configure the type of inventory
        mReaderConfigCmd.setIncludeTransponderRssi(TriState.YES);
        mReaderConfigCmd.setIncludeChecksum(TriState.YES);
        mReaderConfigCmd.setIncludePC(TriState.YES);
        mReaderConfigCmd.setIncludeDateTime(TriState.YES);
        mReaderConfigCmd.setIncludePhase(TriState.YES);
        mReaderConfigCmd.setIncludeEpc(TriState.YES);
        mReaderConfigCmd.setIncludeChannelFrequency(TriState.YES);
        mReaderConfigCmd.setIncludeIndex(TriState.YES);

        DeviceProperties deviceProperties = getCommander().getDeviceProperties();
        if (deviceProperties != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader MinimumCarrierPower:" + deviceProperties.getMinimumCarrierPower());
            Log.d(LOG_TAG, LOG_PREFIX + "Reader MaximumCarrierPower:" + deviceProperties.getMaximumCarrierPower());
            mReaderConfigCmd.setOutputPower(deviceProperties.getMaximumCarrierPower());
        }

        return mReaderConfigCmd;
    }

    public boolean updateReaderConfigCmd(JSONObject configParams) {
        //TODO change below parameters based on config values from UI

        // This is the command that will be used to perform configuration changes and inventories
        Log.d(LOG_TAG, LOG_PREFIX + "configuring InventoryCommand object");
        mReaderConfigCmd = new InventoryCommand();
        mReaderConfigCmd.setResetParameters(TriState.YES);
        // Configure the type of inventory
        mReaderConfigCmd.setIncludeTransponderRssi(TriState.YES);
        mReaderConfigCmd.setIncludeChecksum(TriState.YES);
        mReaderConfigCmd.setIncludePC(TriState.YES);
        mReaderConfigCmd.setIncludeDateTime(TriState.YES);

        DeviceProperties deviceProperties = getCommander().getDeviceProperties();
        if (deviceProperties != null) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader MinimumCarrierPower:" + deviceProperties.getMinimumCarrierPower());
            Log.d(LOG_TAG, LOG_PREFIX + "Reader MaximumCarrierPower:" + deviceProperties.getMaximumCarrierPower());
            mReaderConfigCmd.setOutputPower(deviceProperties.getMaximumCarrierPower());
        }

        return true;
    }

    //
    // Perform an inventory scan with the current command parameters
    //TODO execute this command using Rxjava in the background thread
    public synchronized void scanTags() {
        Log.d(LOG_TAG, LOG_PREFIX + "InventoryModel scan called");
        if (mIsReaderBusy) {
            sendErrorEvent("Reader is Busy");
            return;
        }
        testForAntenna();
        if (getCommander().isConnected()) {
            Log.d(LOG_TAG, LOG_PREFIX + "Connected=true");
            Log.d(LOG_TAG, LOG_PREFIX + "executing Tag Scan Command");
            getReaderConfigCmd().setTakeNoAction(TriState.NO);
            getCommander().executeCommand(getReaderConfigCmd());
        } else {
            sendErrorEvent("Device not connected");
        }
        return;
    }

    // Test for the presence of the antenna
    public synchronized void testForAntenna() {
        Log.d(LOG_TAG, LOG_PREFIX + "testForAntenna called");
        if (getCommander().isConnected()) {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader Connected = true");
            InventoryCommand testCommand = InventoryCommand.synchronousCommand();
            testCommand.setTakeNoAction(TriState.YES);
            getCommander().executeCommand(testCommand);
            if (!testCommand.isSuccessful()) {
                Log.d(LOG_TAG, LOG_PREFIX + "testCommand is not successful");
                Log.d(LOG_TAG, LOG_PREFIX + "ER:Error! Code: " + testCommand.getErrorCode() + " " + testCommand.getMessages().toString());
                sendErrorEvent("ER:Error! Code: " + testCommand.getErrorCode() + " " + testCommand.getMessages().toString());
            }
        } else {
            Log.d(LOG_TAG, LOG_PREFIX + "testCommand is successful");
        }
    }

    protected JSONObject getFormattedEvent(String eventType, String eventValue) {
        return Util.getJson(eventType, eventValue);
    }

    private void sendTagEvent(String eventValue) {
        if (null != mInventoryCallback) {
            mInventoryCallback.onTagDetectedEvent(getFormattedEvent(EVENT_TYPE_TAG, eventValue));
        }
    }

    private void sendBarcodeEvent(String eventValue) {
        if (null != mInventoryCallback) {
            mInventoryCallback.onBarcodeDetectedEvent(getFormattedEvent(EVENT_TYPE_BARCODE, eventValue));
        }
    }

    private void sendErrorEvent(String eventValue) {
        if (null != mInventoryCallback) {
            mInventoryCallback.onErrorEvent(getFormattedEvent(EVENT_TYPE_ERROR, eventValue));
        }
    }

    public void setInventoryCallback(IinventoryModelCallback inventoryCallback) {
        mInventoryCallback = inventoryCallback;
    }

    public interface IinventoryModelCallback {
        void onTagDetectedEvent(JSONObject tagInfoJson);

        void onBarcodeDetectedEvent(JSONObject tagInfoJson);

        void onErrorEvent(JSONObject errJson);
    }
}
