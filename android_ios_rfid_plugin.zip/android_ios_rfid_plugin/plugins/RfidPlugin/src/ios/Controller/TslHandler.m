
#import "TslHandler.h"

@implementation TslHandler
@synthesize tslHandlerDelegate;
BOOL mEnableRfid = true;
BOOL mEnableBarcode = true;

NSString *const TSL_HANDLER_TAG_PREFIX=@"PLUGIN:TslHandler: ";
NSString *const TSL_HANDLER_EVENT_TYPE_ERROR=@"ERROR";
NSString *const TSL_HANDLER_EVENT_READER_INFO=@"READER_INFO";

-(void) connect:(NSString *)readerAddress{
    //readerAddress = @"1166-003793";
    NSLog(@"%@Reader address = %@",TSL_HANDLER_TAG_PREFIX,readerAddress);
    if(connector != nil && [connector checkConnStatus:readerAddress]){
        if([self tslHandlerDelegate] != nil){
            [[self tslHandlerDelegate] onConnected];
            return;
        }else{
            NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
        }
    }
    if(connector == nil){
        NSLog(@"%@Connector object is not initialized, Initializing it",TSL_HANDLER_TAG_PREFIX);
        connector = [[Connector alloc]init];
        [connector setConnectorDelegate:self];
        NSLog(@"%@Connector objcet is initialized",TSL_HANDLER_TAG_PREFIX);
    }
    NSLog(@"%@Calling connect method",TSL_HANDLER_TAG_PREFIX);
    [connector connect:readerAddress];
}

-(void) disconnect{
    NSLog(@"%@TslHandler disconnect method called",TSL_HANDLER_TAG_PREFIX);
    if(connector != nil){
        [connector disconnect];
        return;
    }
    NSLog(@"%@Connector obj is nil",TSL_HANDLER_TAG_PREFIX);
    [self onDisconnected];
}

-(NSString *) getConnectionStatus{
    if(connector != nil){
        return [connector getConnectionStatus];
    }
    return @"DISCONNECTED";
}
//---begin callbacks from connector object----
- (void)onDisconnected {
    NSLog(@"%@Disconnected",TSL_HANDLER_TAG_PREFIX);
    if([self tslHandlerDelegate] != nil){
        [[self tslHandlerDelegate] onDisconnected];
    }else{
        NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
    }
}

- (void)onConnected{
    NSLog(@"%@onConnected called up",TSL_HANDLER_TAG_PREFIX);
    
    if([self tslHandlerDelegate] != nil){
        [[self tslHandlerDelegate] onConnected];
    }else{
        NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
    }
    
    _commander = [connector getCommander];
    if(_commander == nil){
        NSLog(@"%@Commander object is nil, can't proceed",TSL_HANDLER_TAG_PREFIX);
        [self onError:@"Inventory is not ready"];
        return;
    }
    
    if(inventry == nil){
        NSLog(@"%@inventry object is not initialized, initializing it ",TSL_HANDLER_TAG_PREFIX);
        inventry = [[Inventry alloc]init];
        [inventry setInventoryDelegate:self];
        NSLog(@"%@inventry object is initialized ",TSL_HANDLER_TAG_PREFIX);
    }
    
    [inventry initInventory];
    [inventry setCommander:_commander];
    [inventry setRfidEnabled:mEnableRfid];
    [inventry setBarcodeEnabled:mEnableBarcode];
    [inventry setReaderConfig];
}

- (void)onError:(NSString *)errMsg {
    NSLog(@"%@connection error = %@",TSL_HANDLER_TAG_PREFIX,errMsg);
    if([self tslHandlerDelegate] != nil){
        [[self tslHandlerDelegate] onError:[self getJsonMsg:TSL_HANDLER_EVENT_TYPE_ERROR :errMsg]];
    }else{
        NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
    }
}
//---end callbacks from connector object----

//---begin callbacks from Inventory object----
- (void)onTagDetected:(NSDictionary *)tagInfo{
    NSLog(@"%@onTagDetected called up",TSL_HANDLER_TAG_PREFIX);
    if([self tslHandlerDelegate] != nil){
        [[self tslHandlerDelegate] onTagDetected:tagInfo];
    }else{
        NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
    }
}

- (void)onBarcodeDetected:(NSDictionary *)barcodeInfo{
    NSLog(@"%@onBarcodeDetected called up",TSL_HANDLER_TAG_PREFIX);
    if([self tslHandlerDelegate] != nil){
        [[self tslHandlerDelegate] onTagDetected:barcodeInfo];
    }else{
        NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
    }
}

- (void)onErrorEvent:(NSDictionary *)errMsg{
    NSLog(@"%@Inventory error = %@",TSL_HANDLER_TAG_PREFIX,errMsg);
    if([self tslHandlerDelegate] != nil){
        [[self tslHandlerDelegate] onError:errMsg];
    }else{
        NSLog(@"%@tslHandlerDelegate is not initialized ",TSL_HANDLER_TAG_PREFIX);
    }
}

-(NSDictionary *)getReaderProps{
    @synchronized (self) {
        
        if(connector != nil && [[connector getConnectionStatus] isEqualToString:@"CONNECTED"]){
            id readerPropsJson = [connector getReaderProps];
            if(readerPropsJson == nil){
                return [self getJsonMsg:TSL_HANDLER_EVENT_TYPE_ERROR :[connector getErrMsg]];
            }
            NSLog(@"%@Reader properties = %@",TSL_HANDLER_TAG_PREFIX,readerPropsJson);
            return [self getJsonMsg:TSL_HANDLER_EVENT_READER_INFO :readerPropsJson];
        }
        else {
            NSLog(@"%@Connector object is not initialized ",TSL_HANDLER_TAG_PREFIX);
            return [self getJsonMsg:TSL_HANDLER_EVENT_TYPE_ERROR :@"Reader disconnected"];
        }
    }
}

- (void)setEnableRfid:(BOOL)value {
    NSLog(@"%@setEnable rfid called with value: %@",TSL_HANDLER_TAG_PREFIX,value ? @"TRUE":@"FALSE");
    mEnableRfid = value;
    if(inventry != nil)
        [inventry setRfidEnabled:value];
    else
        NSLog(@"%@inventory object is not initialized ",TSL_HANDLER_TAG_PREFIX);
}

- (void)setEnableBarcode:(BOOL)value {
    NSLog(@"%@setEnable barcode called:%@",TSL_HANDLER_TAG_PREFIX,value ? @"TRUE":@"FALSE");
    mEnableBarcode = value;
    if(inventry != nil){
        [inventry setBarcodeEnabled:value];
    }else{
        NSLog(@"%@inventory object is not initialized ",TSL_HANDLER_TAG_PREFIX);
        //TODO send event to ionic UI
    }
}

-(void)scanTags{
    @synchronized (self) {
        
        NSLog(@"%@scanTags called up",TSL_HANDLER_TAG_PREFIX);
        if(connector == nil){
            [self onError:@"Reader not connected"];
            return;
        }
        if(![[connector getConnectionStatus] isEqualToString:@"CONNECTED"]){
            [self onError:@"Reader not connected"];
            return;
        }
        if(inventry != nil){
            [inventry scanTags];
        }else{
            NSLog(@"%@inventory object is not initialized ",TSL_HANDLER_TAG_PREFIX);
            [self onError:@"Inventory is not ready"];
            return;
        }
    }
}

-(NSDictionary *) getJsonMsg:(NSString*)eventType :(NSString*)eventValue{
    NSDictionary *dict= @{
        @"eventType": eventType,
        @"eventValue": eventValue,
    };
    return dict;
}

@end
