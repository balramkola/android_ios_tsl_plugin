module.exports = {
    startScan: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'BTDeviceList', 'start_scan', []);
    },
    stoptScan: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'BTDeviceList', 'stop_scan', []);
    },
    getBondedDevices: function (successCallback, errorCallback) {
        cordova.exec(successCallback, errorCallback, 'BTDeviceList', 'getBondedDevices', []);
    }
};

