/********* BTDeviceList.m Cordova Plugin Implementation *******/

#import <Cordova/CDV.h>
#import <UIKit/UIKit.h>
#import <ExternalAccessory/ExternalAccessory.h>
#import <ExternalAccessory/EAAccessoryManager.h>

@interface BTDeviceList : CDVPlugin {
    NSString* mEventsCallbackId;
}

- (void)start_scan:(CDVInvokedUrlCommand*)command;
- (void)stop_scan:(CDVInvokedUrlCommand*)command;
- (void)getBondedDevices:(CDVInvokedUrlCommand*)command;
- (void)regStateChanges;
- (void)unregStateChanges;
- (void)showList;

@end

@implementation BTDeviceList

NSString *const BT_TAG_PREFIX=@"PLUGIN:BTDeviceList: ";

-(void)viewWillDisappear:(BOOL)animated
{
    NSLog(@"%@viewWillDisappear called",BT_TAG_PREFIX);
    [self unregStateChanges];
}

-(void)viewWillAppear:(BOOL)animated
{
    NSLog(@"%@viewWillAppear called",BT_TAG_PREFIX);
    [self regStateChanges];
}

- (void)start_scan:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@start_scan action called up",BT_TAG_PREFIX);
    mEventsCallbackId = command.callbackId;
    [self sendBondedDevices];
    [self.commandDelegate runInBackground:^{
        @synchronized (self){
            [self regStateChanges];
            [self showList];
        }
    }];
}

- (void)getBondedDevices:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@getBondedDevices action called up",BT_TAG_PREFIX);
    mEventsCallbackId = command.callbackId;
    [self sendBondedDevices];
}

- (void)sendBondedDevices{
    NSLog(@"%@sendBondedDevices called up",BT_TAG_PREFIX);
    EAAccessoryManager *accessoryManager = [EAAccessoryManager sharedAccessoryManager];
    if(accessoryManager == nil){
        NSLog(@"%@Bluetooth API is not available",BT_TAG_PREFIX);
        [self sendEvent:@"ERROR":@"Bluetooth API is not available"];
        return;
    }
    NSArray *accessories = [accessoryManager connectedAccessories];
    if (accessories.count == 0) {
        NSLog(@"%@Accessories list is empty",BT_TAG_PREFIX);
        [self sendEvent:@"ERROR":@"Accessories list is empty"];
        return ;
    }
    
    EAAccessory *accessory;
    for (int i = 0 ; i < [accessories count] ; i++)
    {
        accessory = [accessories objectAtIndex:i];
        NSMutableDictionary *accessoryInfo = [[NSMutableDictionary alloc] init];
        
        [accessoryInfo setObject:(accessory.name == nil ) ? @"n/a" : accessory.name forKey:@"name"];
        [accessoryInfo setObject:(accessory.serialNumber == nil ) ? @"n/a" : accessory.serialNumber forKey:@"address"];
        [accessoryInfo setObject:@"true" forKey:@"paired"];
        
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:accessoryInfo
                                                           options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                             error:&error];
        
        if (!jsonData) {
            NSLog(@"Got an error while converting map to json string: %@", error);
            [self sendEvent:@"ERROR":[error localizedDescription]];
        } else {
            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            [self sendEvent:@"BONDED_DEVICE":jsonString];
        }
    }
}

- (void)stop_scan:(CDVInvokedUrlCommand*)command{
    NSLog(@"%@stop_scan action called up",BT_TAG_PREFIX);
    [self unregStateChanges];
}

- (void)showList{
    [[EAAccessoryManager sharedAccessoryManager] showBluetoothAccessoryPickerWithNameFilter:nil completion:^(NSError *error)
     {
         if( error == nil )
         {
             // Inform the user that the device is being connected
//             _hud = [TSLProgressHUD updateHUD:_hud inView:self.view forBusyState:YES withMessage:@"Waiting for device..."];
         }
         else
         {
             NSString *errorMessage = nil;
             //NSDictionary *info = error.userInfo;
             switch (error.code)
             {
                 case EABluetoothAccessoryPickerAlreadyConnected:
                 {
                     NSLog(@"AlreadyConnected");
                     errorMessage = @"That device is already paired!\n\nTry again and wait a few seconds before choosing. Already paired devices will disappear from the list!";
                 }
                     break;
                     
                 case EABluetoothAccessoryPickerResultFailed:
                     NSLog(@"Failed");
                     errorMessage = @"Failed to connect to that device!\n\nEnsure a supported device has been selected, is powered on and that the blue LED is flashing.";
                     break;
                 case EABluetoothAccessoryPickerResultNotFound:
                     NSLog(@"NotFound");
                     errorMessage = @"Unable to find that device!\n\nEnsure a supported device has been selected, is powered on and that the blue LED is flashing.";
                     break;
                     
                 case EABluetoothAccessoryPickerResultCancelled:
                     NSLog(@"Cancelled");
                     break;
                     
                 default:
                     break;
             }
             if(errorMessage)
             {
                 [self sendEvent:@"Error":errorMessage];
             }
             [self unregStateChanges];
         }
     }];
}

- (void)regStateChanges{
    NSLog(@"%@regStateChanges called up",BT_TAG_PREFIX);
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_accessoryDidConnect:) name:EAAccessoryDidConnectNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(_accessoryDidDisconnect:) name:EAAccessoryDidDisconnectNotification object:nil];
    [[EAAccessoryManager sharedAccessoryManager] registerForLocalNotifications];
}

- (void)unregStateChanges{
    NSLog(@"%@unregStateChanges called up",BT_TAG_PREFIX);
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[EAAccessoryManager sharedAccessoryManager] unregisterForLocalNotifications];
}

-(void) _accessoryDidConnect:(NSNotification *)notification
{
    NSLog(@"%@_accessoryDidConnect called up",BT_TAG_PREFIX);
    EAAccessory *connectedAccessory = [[notification userInfo] objectForKey:EAAccessoryKey];
    // Only notify of change if the accessory added has valid protocol strings
    if( connectedAccessory.protocolStrings.count != 0 )
    {
        NSMutableDictionary *accessoryInfo = [[NSMutableDictionary alloc] init];
        
        [accessoryInfo setObject:(connectedAccessory.name == nil ) ? @"n/a" : connectedAccessory.name forKey:@"name"];
        [accessoryInfo setObject:(connectedAccessory.serialNumber == nil ) ? @"n/a" : connectedAccessory.serialNumber forKey:@"address"];
        [accessoryInfo setObject:@"true" forKey:@"paired"];
        
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:accessoryInfo
                                                           options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                             error:&error];
        
        if (!jsonData) {
            NSLog(@"Got an error while converting map to json string: %@", error);
            [self sendEvent:@"ERROR":[error localizedDescription]];
        } else {
            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            [self sendEvent:@"BONDED_DEVICE":jsonString];
        }
        [self unregStateChanges];
    }
}

-(void) sendEvent:(NSString *)eventType :(NSString *)eventValue{
    NSLog(@"%@sendEvent called up",BT_TAG_PREFIX);
    NSDictionary *finalEventInfo= @{
        @"eventType": eventType,
        @"eventValue": eventValue,
    };
    if(self.webView != nil && mEventsCallbackId != nil){
        NSLog(@"sending event to ionic UI:%@",finalEventInfo);
        CDVPluginResult* pluginResult = nil;
        if(nil == finalEventInfo){
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
        }else{
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:finalEventInfo];
        }
        [pluginResult setKeepCallbackAsBool:false];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:mEventsCallbackId];
    }else{
        NSLog(@"unable to send event info to ionic UI");
    }
}

- (void)_accessoryDidDisconnect:(NSNotification *)notification
{
    NSLog(@"%@_accessoryDidDisconnect called up",BT_TAG_PREFIX);
    EAAccessory *disconnectedAccessory = [[notification userInfo] objectForKey:EAAccessoryKey];
    NSMutableDictionary *accessoryInfo = [[NSMutableDictionary alloc] init];
    
    [accessoryInfo setObject:(disconnectedAccessory.name == nil ) ? @"n/a" : disconnectedAccessory.name forKey:@"name"];
    [accessoryInfo setObject:(disconnectedAccessory.serialNumber == nil ) ? @"n/a" : disconnectedAccessory.serialNumber forKey:@"address"];
    [accessoryInfo setObject:@"false" forKey:@"paired"];
    
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:accessoryInfo
                                                       options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                         error:&error];
    
    if (!jsonData) {
        NSLog(@"Got an error while converting map to json string: %@", error);
        [self sendEvent:@"ERROR":[error localizedDescription]];
    } else {
        NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        [self sendEvent:@"DISCONNECTED":jsonString];
    }
    [self unregStateChanges];
}

@end
