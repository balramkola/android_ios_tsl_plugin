
#import "Inventry.h"

@implementation Inventry

@synthesize inventoryDelegate;
NSString *const INVENTORY_TAG_PREFIX=@"PLUGIN:Inventry: ";
NSString *const EVENT_TYPE_TAG=@"INVENTORY_TAG";
NSString *const EVENT_TYPE_BARCODE=@"INVENTORY_BARCODE";
NSString *const EVENT_TYPE_ERROR=@"ERROR";

-(void) initInventory{
    NSLog(@"%@initInventory method called",INVENTORY_TAG_PREFIX);
    
    if(_inventoryResponder == nil){
        NSLog(@"%@inventoryResponder is not initialized, initializing it",INVENTORY_TAG_PREFIX);
        _inventoryResponder = [[TSLInventoryCommand alloc] init];
        NSLog(@"%@inventoryResponder initialized",INVENTORY_TAG_PREFIX);
    }
    
    //_inventoryResponder.transponderReceivedDelegate = self;
    
    // This formatter will convert any timestamps received
    NSDateFormatter *_dateFormatter = [[NSDateFormatter alloc] init];
    [_dateFormatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    [_dateFormatter setTimeZone:[NSTimeZone localTimeZone]];
    
    //below code is called when tag is detected, if the _inventoryResponder is added to commander otherwise below code block is not called
    _inventoryResponder.transponderDataReceivedBlock = ^(TSLTransponderData *transponder, BOOL moreAvailable)
    {
        NSLog(@"transponderDataReceivedBlock is called");
        self->mAnyTagSeen = true;
        NSMutableDictionary *tagInfoMap = [[NSMutableDictionary alloc] init];
        
        [tagInfoMap setObject:(transponder.epc == nil ) ? @"n/a" : transponder.epc forKey:@"EPC"];
        [tagInfoMap setObject:(transponder.fastTidData == nil) ? @"n/a" : [TSLBinaryEncoding toBase16String:transponder.fastTidData] forKey:@"TidData"];
        [tagInfoMap setObject:(transponder.rssi == nil ) ? @"n/a" : [NSString stringWithFormat:@"%3d", transponder.rssi.intValue] forKey:@"Rssi"];
        [tagInfoMap setObject:(transponder.readData == nil) ? @"n/a" : [TSLBinaryEncoding toBase16String:transponder.readData] forKey:@"ReadData"];
        [tagInfoMap setObject:[TSLTransponderAccessErrorCode descriptionForTransponderAccessErrorCode:transponder.accessErrorCode] forKey:@"AccessError"];
        [tagInfoMap setObject:(transponder.timestamp == nil ) ? @"n/a" : [_dateFormatter stringFromDate: transponder.timestamp] forKey:@"Timestamp"];
        [tagInfoMap setObject:(transponder.pc == nil) ? @"n/a" : [NSString stringWithFormat:@"%04X", transponder.pc.unsignedIntValue ] forKey:@"PC"];
        [tagInfoMap setObject:(transponder.index == nil ) ? @"n/a" : [NSString stringWithFormat:@"%04X", transponder.index.unsignedIntValue ] forKey:@"Index"];
        [tagInfoMap setObject:(transponder.crc == nil) ? @"n/a" : [NSString stringWithFormat:@"%04X", transponder.crc.unsignedIntValue ] forKey:@"CRC"];
        
        NSError *error;
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:tagInfoMap
                                                           options:NSJSONWritingPrettyPrinted // Pass 0 if you don't care about the readability of the generated string
                                                             error:&error];
        
        if (!jsonData) {
            NSLog(@"Got an error while converting map to json string: %@", error);
            [self sendErrorEvent:@"something went wrong"];
        } else {
            NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
            [self sendTagEvent:jsonString];
        }
    };
    
    _inventoryResponder.responseEndedBlock = ^{
        NSLog(@"TSL Reader Response ended");
        TSLInventoryCommand *invCommand = [self getReaderConfigCmd];
        if(!self->mAnyTagSeen && invCommand.takeNoAction != TSL_TriState_YES){
            [self sendTagEvent:@"No Tags found"];
        }
        invCommand.takeNoAction = TSL_TriState_NO;
        self->mIsReaderBusy = false;
    };
    _inventoryResponder.responseBeganBlock = ^{
        NSLog(@"TSL Reader Response began");
        self->mIsReaderBusy = true;
        self->mAnyTagSeen = false;
    };
    
    _inventoryResponder.captureNonLibraryResponses = YES;
    
    //below code handles barcode events
    if(_barcodeResponder == nil){
        NSLog(@"%@barcodeResponder is not initialized, initializing it",INVENTORY_TAG_PREFIX);
        _barcodeResponder = [[TSLBarcodeCommand alloc] init];
        NSLog(@"%@barcodeResponder initialized",INVENTORY_TAG_PREFIX);
    }
    
    _barcodeResponder.captureNonLibraryResponses = YES;
    _barcodeResponder.useEscapeCharacter = TSL_TriState_YES;
    _barcodeResponder.includeDateTime = TSL_TriState_YES;
    _barcodeResponder.barcodeReceivedDelegate = self;
}

- (void)barcodeReceived:(NSString *)barcodeData {
    NSLog(@"%@Detected barcode: %@",INVENTORY_TAG_PREFIX,barcodeData);
    [self sendBarcodeEvent:[@"Barcode:" stringByAppendingString:barcodeData]];
}

-(void) sendBarcodeEvent:(NSString *)eventValue{
    if([self inventoryDelegate] != nil){
        [[self inventoryDelegate] onBarcodeDetected:[self getFormattedEvent:EVENT_TYPE_BARCODE :eventValue]];
    }else{
        NSLog(@"%@inventoryDelegate is not initialized ",INVENTORY_TAG_PREFIX);
    }
}

-(void) sendTagEvent:(NSString *)eventValue{
    NSLog(@"%@sendTagEvent called up",INVENTORY_TAG_PREFIX);
    NSLog(@"%@Detected Tag: %@",INVENTORY_TAG_PREFIX,eventValue);
    if([self inventoryDelegate] != nil){
        [[self inventoryDelegate] onTagDetected:[self getFormattedEvent:EVENT_TYPE_TAG :eventValue]];
    }else{
        NSLog(@"%@inventoryDelegate is not initialized ",INVENTORY_TAG_PREFIX);
    }
}

-(void) sendErrorEvent:(NSString *)eventValue{
    if([self inventoryDelegate] != nil){
        [[self inventoryDelegate] onErrorEvent:[self getFormattedEvent:EVENT_TYPE_ERROR :eventValue]];
    }else{
        NSLog(@"%@inventoryDelegate is not initialized ",INVENTORY_TAG_PREFIX);
    }
}

-(NSDictionary *) getFormattedEvent:(NSString *)eventType :(NSString *)eventValue
{
    NSDictionary *dict= @{
        @"eventType": eventType,
        @"eventValue": eventValue,
    };
    return dict;
}

-(void)setCommander:(TSLAsciiCommander* )commander{
    _commander = commander;
}

-(void)scanTags{
    NSLog(@"%@scanTags method called",INVENTORY_TAG_PREFIX);
    if(mIsReaderBusy){
        [self sendErrorEvent:@"Reader is Busy"];
        return;
    }
    // if(![self testForAntenna])
    //     return;
    if(_commander != nil && _commander.isConnected){
        NSLog(@"%@Reader connected = true",INVENTORY_TAG_PREFIX);
        NSLog(@"%@executing scanTags command",INVENTORY_TAG_PREFIX);
        TSLInventoryCommand *invCommand = [self getReaderConfigCmd];
        invCommand.takeNoAction = TSL_TriState_NO;
        [_commander executeCommand:invCommand];
    }else{
        [self sendErrorEvent:@"Reader not connected"];
    }
}

-(BOOL)testForAntenna{
    NSLog(@"%@testForAntenna method called",INVENTORY_TAG_PREFIX);
    if(_commander != nil && _commander.isConnected){
        NSLog(@"%@Reader connected = true",INVENTORY_TAG_PREFIX);
        TSLInventoryCommand *antennaTestCmd = [TSLInventoryCommand synchronousCommand];
        antennaTestCmd.takeNoAction = TSL_TriState_YES;
        [_commander executeCommand:antennaTestCmd];
        if(![antennaTestCmd isSuccessful]){
            NSLog(@"%@test antennna command is not successfull",INVENTORY_TAG_PREFIX);
            NSString *errMsg = [NSString stringWithFormat:@"%@ER:Error! Code:%@ %@",INVENTORY_TAG_PREFIX,[antennaTestCmd errorCode],[antennaTestCmd messages]];
            NSLog(@"%@", errMsg);
            [self sendErrorEvent:errMsg];
            return FALSE;
        }
    }else{
        NSLog(@"%@test antennna command is not successfull",INVENTORY_TAG_PREFIX);
        [self sendErrorEvent:@"Reader Disconnected"];
        return FALSE;
    }
    return TRUE;
}

-(void)setRfidEnabled:(bool)value{
    bool oldState = mRfidEnabled;
    mRfidEnabled = value;
    if(oldState!=value){
        if(mRfidEnabled){
            if(_commander == nil){
                NSLog(@"%@commander is null, unable to add inventory responder to commander",INVENTORY_TAG_PREFIX);
                return;
            }
            NSLog(@"%@_inventoryResponder added to commander to receive tag events",INVENTORY_TAG_PREFIX);
            [_commander addResponder:_inventoryResponder];
        }else{
            if(_commander == nil){
                NSLog(@"%@commander is null, unable to add inventory responder to commander",INVENTORY_TAG_PREFIX);
                return;
            }
            NSLog(@"%@_inventoryResponder removed from commander to not receive tag events",INVENTORY_TAG_PREFIX);
            [_commander removeResponder:_inventoryResponder];
        }
    }else{
        NSLog(@"%@ old state is same as new state, not taking any action",INVENTORY_TAG_PREFIX);
    }
}

-(void)setBarcodeEnabled:(bool)value{
    bool oldState = mBarcodeEnabled;
    mBarcodeEnabled = value;
    if(oldState!=value){
        if(mBarcodeEnabled){
            if(_commander == nil){
                NSLog(@"%@commander is null, unable to add barcode responder to commander",INVENTORY_TAG_PREFIX);
                return;
            }
            NSLog(@"%@_barcodeResponder added to commander to receive barcode events",INVENTORY_TAG_PREFIX);
            [_commander addResponder:_barcodeResponder];
        }else{
            if(_commander == nil){
                NSLog(@"%@commander is null, unable to add barcode responder to commander",INVENTORY_TAG_PREFIX);
                return;
            }
            NSLog(@"%@_barcodeResponder removed from commander to not receive barcode events",INVENTORY_TAG_PREFIX);
            [_commander removeResponder:_barcodeResponder];
        }
    }
}

-(void)setReaderConfig{
    if(_commander != nil && _commander.isConnected){
        bool rfidEnabled= mRfidEnabled;
        bool barcodeEnabled = mBarcodeEnabled;
        [self setRfidEnabled:false];
        [self setBarcodeEnabled:false];
        TSLInventoryCommand *invCommand = [self getReaderConfigCmd];
        invCommand.takeNoAction = TSL_TriState_YES;
        [self resetDevice];
        NSLog(@"%@executing configuration command",INVENTORY_TAG_PREFIX);
        [_commander executeCommand:invCommand];
        [self setRfidEnabled:rfidEnabled];
        [self setBarcodeEnabled:barcodeEnabled];
        return;
    }
    NSLog(@"%@either commander is nill or reader is not connected",INVENTORY_TAG_PREFIX);
}

-(void)resetDevice{
    if(_commander != nil && _commander.isConnected){
        NSLog(@"%@executing factory reset command",INVENTORY_TAG_PREFIX);
        TSLFactoryDefaultsCommand *fdCommand = [[TSLFactoryDefaultsCommand alloc] init];
        fdCommand.resetParameters = TSL_TriState_YES;
        [_commander executeCommand:fdCommand];
        return;
    }
    NSLog(@"%@either commander is nill or reader is not connected",INVENTORY_TAG_PREFIX);
}

-(TSLInventoryCommand* ) getReaderConfigCmd{
    if(mReaderConfigCmd != nil){
        NSLog(@"%@mReaderConfigCmd is already initialized, returning it",INVENTORY_TAG_PREFIX);
        return mReaderConfigCmd;
    }
    NSLog(@"%@mReaderConfigCmd is not initialized, initializing it",INVENTORY_TAG_PREFIX);
    mReaderConfigCmd = [[TSLInventoryCommand alloc] init];
    mReaderConfigCmd.includeTransponderRSSI = TSL_TriState_YES;
    mReaderConfigCmd.includeEPC = TSL_TriState_YES;
    mReaderConfigCmd.includePC = TSL_TriState_YES;
    mReaderConfigCmd.includeDateTime = TSL_TriState_YES;
    mReaderConfigCmd.includeChecksum = TSL_TriState_YES;
    mReaderConfigCmd.outputPower = [TSLInventoryCommand maximumOutputPower];
    
    return mReaderConfigCmd;
}

//- (void)transponderReceived:(NSString *)epc crc:(NSNumber *)crc pc:(NSNumber *)pc rssi:(NSNumber *)rssi fastId:(NSData *)fastId moreAvailable:(BOOL)moreAvailable {
//
//    NSLog(@"%@calling  transponder call back method",INVENTORY_TAG_PREFIX);
//
//    NSLog(@"%@epc tag value = %@",INVENTORY_TAG_PREFIX,epc);
//    NSLog(@"%@crc tag value = %@",INVENTORY_TAG_PREFIX,crc);
//    NSLog(@"%@pc tag value = %@",INVENTORY_TAG_PREFIX,pc);
//    NSLog(@"%@rssi tag value = %@",INVENTORY_TAG_PREFIX,rssi);
//    NSLog(@"%@fastId tag value = %@",INVENTORY_TAG_PREFIX,fastId);
//    mAnyTagSeen = true;
//
//    NSMutableDictionary *gradedetails = [[NSMutableDictionary alloc] init];
//    [gradedetails setObject:@"pass" forKey:@"studentresult"];
//    [gradedetails setObject:@"provided" forKey:@"marksheet"];
//
//    NSMutableDictionary *results = [[NSMutableDictionary alloc] init];
//    [results setObject:gradedetails forKey:@"Grade1"];
//    [results setObject:@"01" forKey:@"ID"];
//    [results setObject:@"Name" forKey:@"Student1"];
//    //TODO call onTagDetected
//}
@end
