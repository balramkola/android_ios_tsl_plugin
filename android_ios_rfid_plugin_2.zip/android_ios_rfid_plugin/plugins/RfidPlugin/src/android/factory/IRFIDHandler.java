package com.techm.rfidplugin.factory;

import android.content.Context;

public interface IRFIDHandler {
    String LIB_INITIALIZED = "LIB_INITIALIZED";

    void initLib(Context activityContext);

    void connect(String macAddress);

    void disconnect();

    void getReaderProps();

    String getConnStatus();

    void setEnableRfid(boolean value);

    void setEnableBarcode(boolean value);

    void scanTags();

    void setCallback(IRFIDHandlerCallback tslHandlerCallback);

    void onPause();

    void onResume();
}
