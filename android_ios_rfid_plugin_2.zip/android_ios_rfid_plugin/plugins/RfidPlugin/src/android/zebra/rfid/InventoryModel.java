package com.techm.rfidplugin.zebra.rfid;

import android.util.Log;

import com.techm.rfidplugin.zebra.utilities.Util;
import com.zebra.rfid.api3.ACCESS_OPERATION_CODE;
import com.zebra.rfid.api3.ACCESS_OPERATION_STATUS;
import com.zebra.rfid.api3.Antennas;
import com.zebra.rfid.api3.ENUM_TRIGGER_MODE;
import com.zebra.rfid.api3.HANDHELD_TRIGGER_EVENT_TYPE;
import com.zebra.rfid.api3.INVENTORY_STATE;
import com.zebra.rfid.api3.InvalidUsageException;
import com.zebra.rfid.api3.OperationFailureException;
import com.zebra.rfid.api3.RFIDReader;
import com.zebra.rfid.api3.RfidEventsListener;
import com.zebra.rfid.api3.RfidReadEvents;
import com.zebra.rfid.api3.RfidStatusEvents;
import com.zebra.rfid.api3.SESSION;
import com.zebra.rfid.api3.SL_FLAG;
import com.zebra.rfid.api3.START_TRIGGER_TYPE;
import com.zebra.rfid.api3.STATUS_EVENT_TYPE;
import com.zebra.rfid.api3.STOP_TRIGGER_TYPE;
import com.zebra.rfid.api3.TagData;
import com.zebra.rfid.api3.TriggerInfo;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class InventoryModel implements RfidEventsListener {

    private static final String LOG_TAG = InventoryModel.class.getSimpleName();
    private static final String LOG_PREFIX = "PLUGIN: ";
    private static final String EVENT_TYPE_TAG = "INVENTORY_TAG";
    private static final String EVENT_TYPE_ERROR = "ERROR";

    private boolean mRfidEnabled;

    private InventoryModel.IinventoryModelCallback mInventoryCallback = null;
    private RFIDReader mReader = null;
    private boolean mIsReaderBusy = false;

    //enable it to get tag info from Reader
    public void setRfidEnabled(boolean state) {
        boolean oldState = mRfidEnabled;
        mRfidEnabled = state;

        if (oldState != state) {
            if (mRfidEnabled) {
                Log.d(LOG_TAG, LOG_PREFIX + "adding Event Tag Listener to Reader to receive detected RFID tags info");
                // Listen for transponders/RFID tags detections and trigger press events
                addTagEventListener();
            } else {
                Log.d(LOG_TAG, LOG_PREFIX + "removing Event Tag Listener from Reader");
                // Stop listening for transponders and trigger press events
                deleteTagEventListener();
            }
        }
    }

    private void deleteTagEventListener() {
        try {
            if (mReader != null && mReader.Events != null) {
                Log.d(LOG_TAG, LOG_PREFIX + "unregistering tag events");
                mReader.Events.removeEventsListener(InventoryModel.this);
                // HH event
                mReader.Events.setHandheldEvent(false);
                // tag event with tag data
                mReader.Events.setTagReadEvent(false);
                mReader.Events.setAttachTagDataWithReadEvent(false);
            } else {
                //TODO reader is not connected unable to delete event listener
            }
        } catch (InvalidUsageException | OperationFailureException e) {
            Log.d(LOG_TAG, LOG_PREFIX + "error while deleting listener:" + e.getMessage());
            sendErrorEvent(e.getMessage());
        }
    }

    private void addTagEventListener() {
        if (mReader == null || !mReader.isConnected()) {
            //TODO reader is not connected unable to add event listener
            Log.d(LOG_TAG, LOG_PREFIX + "reader is not connected unable to add event listener");
            sendErrorEvent("Reader is not connected");
            return;
        }
        try {
            if (mReader.Events != null) {
                Log.d(LOG_TAG, LOG_PREFIX + "registering for tag events");
                // receive events from reader
                mReader.Events.addEventsListener(InventoryModel.this);
                // HH event
                mReader.Events.setHandheldEvent(true);
                // tag event with tag data
                mReader.Events.setTagReadEvent(true);
                mReader.Events.setAttachTagDataWithReadEvent(true);
            }
        } catch (InvalidUsageException | OperationFailureException e) {
            Log.d(LOG_TAG, LOG_PREFIX + "error while adding listener:" + e.getMessage());
            sendErrorEvent(e.getMessage());
        }
    }

    public void setReader(RFIDReader reader) {
        mReader = reader;
    }

    public InventoryModel() {
        Log.d(LOG_TAG, LOG_PREFIX + "called InventoryModel()");
        //setRfidEnabled(true);//default value is enabled
    }

    //TODO run this in the background thread
    public void setReaderConfig() {
        Log.d(LOG_TAG, LOG_PREFIX + "setReaderConfig() called");
        if (mReader != null && mReader.isConnected()) {
            TriggerInfo triggerInfo = new TriggerInfo();
            triggerInfo.StartTrigger.setTriggerType(START_TRIGGER_TYPE.START_TRIGGER_TYPE_IMMEDIATE);
            triggerInfo.StopTrigger.setTriggerType(STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_IMMEDIATE);
            try {
                // set trigger mode as rfid so scanner beam will not come
                mReader.Config.setTriggerMode(ENUM_TRIGGER_MODE.RFID_MODE, true);
                // set start and stop triggers
                mReader.Config.setStartTrigger(triggerInfo.StartTrigger);
                mReader.Config.setStopTrigger(triggerInfo.StopTrigger);
                // power levels are index based so maximum power supported get the last one
                int maxPower = mReader.ReaderCapabilities.getTransmitPowerLevelValues().length - 1;
                // set antenna configurations
                Antennas.AntennaRfConfig config = mReader.Config.Antennas.getAntennaRfConfig(1);
                config.setTransmitPowerIndex(maxPower);
                config.setrfModeTableIndex(0);
                config.setTari(0);
                mReader.Config.Antennas.setAntennaRfConfig(1, config);
                // Set the singulation control
                Antennas.SingulationControl s1_singulationControl = mReader.Config.Antennas.getSingulationControl(1);
                s1_singulationControl.setSession(SESSION.SESSION_S0);
                s1_singulationControl.Action.setInventoryState(INVENTORY_STATE.INVENTORY_STATE_A);
                s1_singulationControl.Action.setSLFlag(SL_FLAG.SL_ALL);
                mReader.Config.Antennas.setSingulationControl(1, s1_singulationControl);
                // delete any prefilters
                mReader.Actions.PreFilters.deleteAll();
            } catch (InvalidUsageException | OperationFailureException e) {
                e.printStackTrace();
                Log.d(LOG_TAG, LOG_PREFIX + "error while configuring reader:" + e.getMessage());
                sendErrorEvent(e.getMessage());
            }
        } else {
            Log.d(LOG_TAG, LOG_PREFIX + "Reader is not connected");
            sendErrorEvent("Reader is not connected");
        }
    }

    public boolean updateReaderConfigCmd(JSONObject configParams) {
        //TODO change config parameters based on config values from UI
        return true;
    }

    //
    // Perform an inventory scan with the current command parameters
    //TODO execute this in the background thread
    public synchronized void scanTags() {
        Log.d(LOG_TAG, LOG_PREFIX + "InventoryModel scan called");
        if (mIsReaderBusy) {
            sendErrorEvent("Reader is Busy");
            return;
        }
        //TODO call perform Inventory and stop Inventory with some time delay
        if (!performInventory())
            return;
        //time delay
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
            Log.d(LOG_TAG, LOG_PREFIX + "error in sleep thread:" + e.getMessage());
        }
        stopInventory();
        return;
    }

    protected JSONObject getFormattedEvent(String eventType, String eventValue) {
        return Util.getJson(eventType, eventValue);
    }

    private void sendTagEvent(String eventValue) {
        if (null != mInventoryCallback) {
            mInventoryCallback.onTagDetectedEvent(getFormattedEvent(EVENT_TYPE_TAG, eventValue));
        }
    }

    private void sendErrorEvent(String eventValue) {
        if (null != mInventoryCallback) {
            mInventoryCallback.onErrorEvent(getFormattedEvent(EVENT_TYPE_ERROR, eventValue));
        }
    }

    public void setInventoryCallback(IinventoryModelCallback inventoryCallback) {
        mInventoryCallback = inventoryCallback;
    }

    public interface IinventoryModelCallback {
        void onTagDetectedEvent(JSONObject tagInfoJson);

        void onErrorEvent(JSONObject errJson);
    }

    // Read/Status Notify handler
    // Implement the RfidEventsLister class to receive event notifications
    @Override
    public void eventReadNotify(RfidReadEvents event) {
        // Recommended to use new method getReadTagsEx for better performance in case of large tag population
        if (mReader == null || event.getReadEventData() == null) {
            return;
        }
        //TagData[] tags = mReader.Actions.getReadTags(100);
        TagData tagData = event.getReadEventData().tagData;
        if (tagData != null) {
            //TODO send these bulk tags using RxJava in the background
            //if (tags != null) {
            //for (TagData tagData : tags) {
            Log.d(LOG_TAG, LOG_PREFIX + "EPC " + tagData.getTagID());

            Map<String, String> map = new HashMap<String, String>();
            map.put("EPC", tagData.getTagID());
            map.put("PC", "" + tagData.getPC());
            if (tagData.getOpCode() == ACCESS_OPERATION_CODE.ACCESS_OPERATION_READ &&
                    tagData.getOpStatus() == ACCESS_OPERATION_STATUS.ACCESS_SUCCESS) {
                if (tagData.getMemoryBankData().length() > 0) {
                    Log.d(LOG_TAG, LOG_PREFIX + " Mem Bank Data " + tagData.getMemoryBankData());
                    map.put("ReadData", tagData.getMemoryBankData());
                }
            }
            if (tagData.isContainsLocationInfo()) {
                short dist = tagData.LocationInfo.getRelativeDistance();
                Log.d(LOG_TAG, LOG_PREFIX + "Tag relative distance " + dist);
                map.put("RelativeDistance", "" + dist);
            }
            map.put("Rssi", "" + tagData.getPeakRSSI());
            if (null != tagData.getTagEventTimeStamp()) {
                map.put("Timestamp", "" + tagData.getTagEventTimeStamp().ConvertTimetoString());
            }
//                    map.put("CRC",""+tagData.getCRC());
//                    map.put("PC", ""+tagData.getPC());
//                    map.put("Index",""+tagData.getChannelIndex());
//                    map.put("Phase",""+tagData.getPhase());
            map.put("TagSeenCount", "" + tagData.getTagSeenCount());
            JSONObject tagInfo = new JSONObject(map);
            Log.d(LOG_TAG, LOG_PREFIX + "Tag info:" + tagInfo.toString());
            sendTagEvent(tagInfo.toString());
            //}
        }
    }

    // Status Event Notification
    @Override
    public void eventStatusNotify(RfidStatusEvents rfidStatusEvents) {
        Log.d(LOG_TAG, LOG_PREFIX + "RfidStatusEvents: " + rfidStatusEvents.StatusEventData.getStatusEventType());
        if (rfidStatusEvents.StatusEventData.getStatusEventType() == STATUS_EVENT_TYPE.HANDHELD_TRIGGER_EVENT) {
            if (rfidStatusEvents.StatusEventData.HandheldTriggerEventData.getHandheldEvent() == HANDHELD_TRIGGER_EVENT_TYPE.HANDHELD_TRIGGER_PRESSED) {
                Log.d(LOG_TAG, LOG_PREFIX + "HANDHELD_TRIGGER_PRESSED");
                performInventory();
            }
            if (rfidStatusEvents.StatusEventData.HandheldTriggerEventData.getHandheldEvent() == HANDHELD_TRIGGER_EVENT_TYPE.HANDHELD_TRIGGER_RELEASED) {
                Log.d(LOG_TAG, LOG_PREFIX + "HANDHELD_TRIGGER_RELEASED");
                stopInventory();
            }
        }
    }

    private boolean isReaderConnected() {
        if (mReader != null && mReader.isConnected())
            return true;
        else {
            Log.d(LOG_TAG, LOG_PREFIX + "reader is not connected");
            sendErrorEvent("Reader not connected");
            return false;
        }
    }

    synchronized private boolean performInventory() {
        Log.d(LOG_TAG, LOG_PREFIX + "performInventory() called");
        // check reader connection
        if (!isReaderConnected()) {
            sendErrorEvent("Device disconnected");
            return false;
        }
        try {
            mIsReaderBusy = true;
            mReader.Actions.Inventory.perform();
        } catch (InvalidUsageException | OperationFailureException e) {
            Log.d(LOG_TAG, LOG_PREFIX + "error while starting inventory scan command:" + e.getMessage());
            sendErrorEvent(e.getMessage());
            return false;
        }
        return true;
    }

    synchronized private void stopInventory() {
        Log.d(LOG_TAG, LOG_PREFIX + "stopInventory() called");
        // check reader connection
        if (!isReaderConnected())
            return;
        try {
            mReader.Actions.Inventory.stop();
            mIsReaderBusy = false;
        } catch (InvalidUsageException | OperationFailureException e) {
            Log.d(LOG_TAG, LOG_PREFIX + "error while stopping inventory scan command:" + e.getMessage());
            sendErrorEvent(e.getMessage());
        }
    }
}
