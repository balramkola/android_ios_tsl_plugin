import { CordovaOptions } from './interfaces';
export declare function cordova(pluginObj: any, methodName: string, config: CordovaOptions, args: IArguments | any[]): any;
